"""General plotting primitives.

ONE general drawing function (`draw`) plus small composable helpers, so chart modules
never duplicate styling code. Everything draws onto a caller-provided Axes, which keeps
it compatible with both one-off figures and the reused-figure performance path.

Supported out of the box (the edge cases that matter):
  - multiple series, line or scatter, with per-series label/color/marker/style
  - dashed constant reference lines (horizontal or vertical) with optional inline labels
  - in-axes text boxes (annotations) and figure-level notes/footnotes
  - time-gradient scatter with colorbar (for encoding elapsed time without a 3rd axis)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

from . import config
from .axis_range import AxisRange


@dataclass
class SeriesSpec:
    x: Sequence
    y: Sequence
    label: str | None = None
    kind: str = "line"               # "line" | "scatter"
    color: object | None = None
    marker: str = "o"
    markersize: float = 3.0
    linewidth: float = config.LINE_WIDTH
    linestyle: str = "-"
    alpha: float = 1.0


@dataclass
class RefLine:
    """A dashed constant-value reference line (e.g. stoichiometric ratio, safety limit)."""
    value: float
    axis: str = "h"                  # "h" -> horizontal (y=value); "v" -> vertical (x=value)
    label: str | None = None
    color: object = "gray"
    linestyle: str = "--"
    linewidth: float = 1.0


@dataclass
class TextBox:
    """Free-floating annotation in axes-fraction coordinates."""
    text: str
    loc: tuple[float, float] = (0.02, 0.98)
    ha: str = "left"
    va: str = "top"
    fontsize: float = 9.0


def add_constant_line(ax, ref: RefLine) -> None:
    line_fn = ax.axhline if ref.axis == "h" else ax.axvline
    line_fn(ref.value, color=ref.color, linestyle=ref.linestyle, linewidth=ref.linewidth)
    if ref.label:
        if ref.axis == "h":
            ax.text(0.99, ref.value, f" {ref.label}", transform=ax.get_yaxis_transform(),
                    ha="right", va="bottom", fontsize=8, color=ref.color)
        else:
            ax.text(ref.value, 0.99, f" {ref.label}", transform=ax.get_xaxis_transform(),
                    ha="left", va="top", fontsize=8, color=ref.color, rotation=90)


def add_textbox(ax, box: TextBox) -> None:
    ax.text(box.loc[0], box.loc[1], box.text, transform=ax.transAxes,
            ha=box.ha, va=box.va, fontsize=box.fontsize,
            bbox=dict(boxstyle="round", facecolor="white", alpha=0.8, edgecolor="0.7"))


def add_note(fig, text: str) -> None:
    """Figure-level footnote (small, bottom-centered)."""
    fig.text(0.5, 0.01, text, ha="center", va="bottom", fontsize=8, color="0.35")


def draw(ax, series: list[SeriesSpec], *, xlabel: str, ylabel: str,
         title: str | None = None, ref_lines: Sequence[RefLine] = (),
         textboxes: Sequence[TextBox] = (), legend: bool = True,
         xscale: str = "linear", yscale: str = "linear") -> None:
    """Draw a complete single-axes chart onto `ax`."""
    for s in series:
        if s.kind == "scatter":
            ax.scatter(s.x, s.y, label=s.label, color=s.color, marker=s.marker,
                       s=config.SCATTER_MARKER_SIZE, alpha=s.alpha)
        else:
            ax.plot(s.x, s.y, label=s.label, color=s.color, marker=s.marker,
                    markersize=s.markersize, linewidth=s.linewidth,
                    linestyle=s.linestyle, alpha=s.alpha)

    for ref in ref_lines:
        add_constant_line(ax, ref)
    for box in textboxes:
        add_textbox(ax, box)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title)
    if xscale != "linear":
        ax.set_xscale(xscale)
    if yscale != "linear":
        ax.set_yscale(yscale)
    if legend and any(s.label for s in series):
        ax.legend(loc="best")


def gradient_scatter(ax, x, y, c, *, cmap: str | None = None, label: str | None = None):
    """Scatter colored by `c` (e.g. elapsed seconds). Returns the mappable for a colorbar."""
    return ax.scatter(x, y, c=c, cmap=cmap or config.TIME_GRADIENT_CMAP,
                      s=config.SCATTER_MARKER_SIZE, label=label)


# ---------------------------------------------------------------------------
# Axis-range policy: resolve the configured AxisRange for an axis and apply it.
# (Policy table + precedence live in config.py; the value type in axis_range.py.)
# ---------------------------------------------------------------------------

def axis_range_for(yvar: str, xvar: str, axis: str, var: str) -> AxisRange:
    """Effective range policy for one axis. Precedence: BY_CHART > BY_VAR > DEFAULT."""
    per_axis = config.AXIS_RANGE_BY_CHART.get((yvar, xvar))
    if per_axis and axis in per_axis:
        return per_axis[axis]
    return config.AXIS_RANGE_BY_VAR.get(var, config.AXIS_RANGE_DEFAULT)


def apply_chart_axis_ranges(ax, *, xvar: str, yvar: str, x, y) -> None:
    """Apply the configured x/y range policies for a paired (xvar, yvar) chart.

    Call AFTER plotting so the policy overrides matplotlib's autoscale. `x`/`y` are the
    actual plotted arrays (only consulted for autoclip percentiles).
    """
    x_lo, x_hi = axis_range_for(yvar, xvar, "x", xvar).limits(x)
    if x_lo is not None or x_hi is not None:
        ax.set_xlim(left=x_lo, right=x_hi)
    y_lo, y_hi = axis_range_for(yvar, xvar, "y", yvar).limits(y)
    if y_lo is not None or y_hi is not None:
        ax.set_ylim(bottom=y_lo, top=y_hi)
