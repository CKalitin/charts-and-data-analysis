"""Derived quantities — the heart of the framework's correctness.

Two layers:
  add_derived_columns(df, cell_count)  -> adds derived per-sample columns to a canonical
                                          time-series DataFrame (computed ONCE per test).
  compute_running_scalars(df, mask)    -> reduces time-series/derived columns to named
                                          per-test scalars under a filter mask.

All math is centralized here so a derived variable is defined in exactly one place.
Division is guarded so idle/zero rows produce NaN rather than inf.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from . import config


def _safe_div(numer: pd.Series, denom: pd.Series, denom_min: float | None = None) -> pd.Series:
    """Elementwise divide; result is NaN where denom is 0/NaN (or below denom_min)."""
    d = denom.astype("float64").copy()
    if denom_min is not None:
        d = d.where(d.abs() >= denom_min)
    d = d.replace(0.0, np.nan)
    return numer.astype("float64") / d


def add_derived_columns(df: pd.DataFrame, cell_count: int | None = None) -> pd.DataFrame:
    """Return `df` with all derivable columns added (in place on a copy).

    Source columns that are absent simply produce no derived column — keeps partial
    data working.
    """
    df = df.copy()
    c = df.columns

    if {"H2_pressure_PSIG", "O2_pressure_PSIG"}.issubset(c):
        df["dP_H2_O2_PSIG"] = df["H2_pressure_PSIG"] - df["O2_pressure_PSIG"]

    if "H2_purity_pct" in c:
        df["H2_impurity_pct"] = 100.0 - df["H2_purity_pct"]
        df["O2_purity_safety_margin_pct"] = (
            df["O2_purity_pct"] - 96.0 if "O2_purity_pct" in c else np.nan
        )
    if "O2_purity_pct" in c:
        df["O2_impurity_pct"] = 100.0 - df["O2_purity_pct"]

    if {"H2_captured_SLPM", "H2_total_SLPM"}.issubset(c):
        df["H2_capture_efficiency"] = _safe_div(df["H2_captured_SLPM"], df["H2_total_SLPM"])
        df["H2_crossover_SLPM"] = df["H2_total_SLPM"] - df["H2_captured_SLPM"]
    if {"O2_captured_SLPM", "O2_total_SLPM"}.issubset(c):
        df["O2_capture_efficiency"] = _safe_div(df["O2_captured_SLPM"], df["O2_total_SLPM"])
        df["O2_crossover_SLPM"] = df["O2_total_SLPM"] - df["O2_captured_SLPM"]

    if {"O2_total_SLPM", "O2_theoretical_SLPM"}.issubset(c):
        df["eta_O2"] = _safe_div(df["O2_total_SLPM"], df["O2_theoretical_SLPM"])

    if {"voltage_V", "current_A"}.issubset(c):
        df["power_W"] = df["voltage_V"] * df["current_A"]
        df["apparent_resistance_ohm"] = _safe_div(
            df["voltage_V"], df["current_A"], denom_min=config.CURRENT_FLOW_THRESHOLD_A
        )

    if "voltage_V" in c and cell_count:
        df["cell_voltage_V"] = df["voltage_V"] / float(cell_count)

    if {"H2_flow_SLPM", "O2_flow_SLPM"}.issubset(c):
        df["flow_ratio_H2_O2"] = _safe_div(df["H2_flow_SLPM"], df["O2_flow_SLPM"])

    if {"power_W", "mdot_H2_gps"}.issubset(df.columns):
        # kWh/kg = kW / (kg/h);  kW = W/1000;  kg/h = (g/s)*3.6
        df["specific_energy_kWh_per_kg"] = _safe_div(
            df["power_W"] / 1000.0, df["mdot_H2_gps"] * 3.6
        )

    return df


# ---------------------------------------------------------------------------
# Scalar reducers
# ---------------------------------------------------------------------------

def _mean(s: pd.Series) -> float:
    return float(np.nanmean(s)) if s.notna().any() else float("nan")


def _peak(s: pd.Series) -> float:
    return float(np.nanmax(s)) if s.notna().any() else float("nan")


def _integral_over_time(values: pd.Series, time: pd.Series) -> float:
    """Trapezoidal integral of `values` (per-second rate) over `time`, in value·seconds."""
    mask = values.notna() & time.notna()
    if mask.sum() < 2:
        return float("nan")
    tt = time[mask]
    # .dt.total_seconds() is resolution-agnostic (timestamps here are microsecond, not ns).
    t = (tt - tt.min()).dt.total_seconds().to_numpy()
    v = values[mask].to_numpy(dtype="float64")
    order = np.argsort(t)
    # np.trapz was removed in NumPy 2.0; np.trapezoid is the replacement.
    trapezoid = getattr(np, "trapezoid", None) or np.trapz
    return float(trapezoid(v[order], t[order]))


def compute_running_scalars(df_derived: pd.DataFrame, mask: pd.Series) -> dict[str, float]:
    """Reduce a derived time-series frame to the registry's `reduced` scalars.

    `mask` selects the window to reduce over (typically current-flowing).
    """
    d = df_derived[mask] if mask is not None else df_derived

    def avg(col: str) -> float:
        return _mean(d[col]) if col in d.columns else float("nan")

    def peak(col: str) -> float:
        return _peak(d[col]) if col in d.columns else float("nan")

    out: dict[str, float] = {
        "avg_h2_purity_running": avg("H2_purity_pct"),
        "avg_o2_purity_running": avg("O2_purity_pct"),
        "avg_h2_impurity_running": avg("H2_impurity_pct"),
        "avg_o2_impurity_running": avg("O2_impurity_pct"),
        "avg_h2_capture_eff_running": avg("H2_capture_efficiency"),
        "avg_o2_capture_eff_running": avg("O2_capture_efficiency"),
        "avg_dp_running": avg("dP_H2_O2_PSIG"),
        "avg_temp_running": avg("stack_temp_C"),
        "peak_temp_running": peak("stack_temp_C"),
        "avg_current_running": avg("current_A"),
        "avg_voltage_running": avg("voltage_V"),
        "avg_cell_voltage_running": avg("cell_voltage_V"),
        "avg_eta_h2_running": avg("eta_H2"),
        "avg_power_running": avg("power_W"),
        "avg_specific_energy_running": avg("specific_energy_kWh_per_kg"),
    }

    if {"mdot_H2_gps", "time"}.issubset(d.columns):
        out["total_h2_produced_g_integral"] = _integral_over_time(d["mdot_H2_gps"], d["time"])
    else:
        out["total_h2_produced_g_integral"] = float("nan")

    return out
