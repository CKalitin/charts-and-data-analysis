"""Test discovery and data loading.

Discovers test directories under raw_data/, and loads the three data products:
  - time series  (electrolysis raw_data.csv)        -> canonical-named DataFrame
  - scalar results (both file formats)              -> flat {canonical: value} dict
  - IV curves                                       -> list of DataFrames

All loaders tolerate missing/empty files (some test dirs have no data) and return
empty/None rather than raising, so the sweep can skip gracefully.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import pandas as pd

from . import config, derived, schema

# Folder name: ID{test_id}_SN{stack:04d}_{YYYY-MM-DD}_{HH-MM-SS}_PDT
_DIR_RE = re.compile(r"^ID(\d+)_SN(\d{4})_(\d{4}-\d{2}-\d{2})_(\d{2}-\d{2}-\d{2})_")


@dataclass(frozen=True)
class TestRecord:
    test_id: int
    stack: int
    test_type: str          # "electrolysis" | "pressure"
    directory: Path
    start: datetime | None  # parsed from the folder name (test start)

    @property
    def label(self) -> str:
        return f"SN{self.stack:04d} · ID{self.test_id}"

    def _file(self, suffix: str) -> Path | None:
        hits = sorted(self.directory.glob(f"*{suffix}"))
        return hits[0] if hits else None

    @property
    def raw_data_path(self) -> Path | None:
        return self._file("_raw_data.csv")

    @property
    def results_path(self) -> Path | None:
        return self._file("_test_results.csv")

    @property
    def iv_dir(self) -> Path:
        return self.directory / "IV Curves"


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------

_TYPE_FOLDER = {
    "electrolysis": schema.TEST_TYPE_ELECTROLYSIS,
    "pressure": schema.TEST_TYPE_PRESSURE,
}


def _excluded(stack: int, test_id: int) -> bool:
    if test_id in config.EXCLUDE_TEST_IDS:
        return True
    return test_id in config.EXCLUDE_TEST_IDS_BY_STACK.get(stack, [])


def _stack_dirs() -> list[Path]:
    if not config.RAW_DATA_ROOT.is_dir():
        return []
    out = []
    for d in sorted(config.RAW_DATA_ROOT.iterdir()):
        m = re.match(r"^SN(\d{4})$", d.name)
        if not m or not d.is_dir():
            continue
        stack = int(m.group(1))
        if config.STACKS is not None and stack not in config.STACKS:
            continue
        out.append(d)
    return out


def discover_tests(test_type: str | None = None) -> list[TestRecord]:
    """Find all test directories. `test_type` in {None, 'electrolysis', 'pressure'}."""
    types = [test_type] if test_type else ["electrolysis", "pressure"]
    records: list[TestRecord] = []
    for stack_dir in _stack_dirs():
        stack = int(stack_dir.name[2:])
        for t in types:
            type_dir = stack_dir / _TYPE_FOLDER[t]
            if not type_dir.is_dir():
                continue
            for test_dir in sorted(type_dir.iterdir()):
                if not test_dir.is_dir():
                    continue
                m = _DIR_RE.match(test_dir.name)
                if not m:
                    continue
                test_id = int(m.group(1))
                if _excluded(stack, test_id):
                    continue
                try:
                    start = datetime.strptime(f"{m.group(3)} {m.group(4)}", "%Y-%m-%d %H-%M-%S")
                except ValueError:
                    start = None
                records.append(TestRecord(test_id, stack, t, test_dir, start))
    records.sort(key=lambda r: (r.stack, r.test_id))
    return records


# ---------------------------------------------------------------------------
# Time series
# ---------------------------------------------------------------------------

def load_timeseries(rec: TestRecord) -> pd.DataFrame | None:
    """Load an electrolysis raw_data.csv into a canonical-named DataFrame.

    Returns None if there is no data file. Columns renamed to canonical names,
    disconnected-TC columns dropped, `time` parsed to datetime, all value columns
    coerced numeric, and TC sentinel values replaced with NaN.
    """
    path = rec.raw_data_path
    if path is None or path.stat().st_size == 0:
        return None
    df = pd.read_csv(path)
    if df.empty:
        return None

    df = df.drop(columns=[c for c in schema.DROP_RAW_COLUMNS if c in df.columns])
    df = df.rename(columns=schema.canonical_timeseries_columns(list(df.columns)))

    if "time" in df.columns:
        df["time"] = pd.to_datetime(df["time"], utc=True, errors="coerce")

    value_cols = [c for c in df.columns if c != "time"]
    for c in value_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # Scrub disconnected-thermocouple sentinel anywhere it slipped through.
    if "stack_temp_C" in df.columns:
        df.loc[df["stack_temp_C"] == config.TC_SENTINEL_C, "stack_temp_C"] = pd.NA

    return df


def load_pressure_timeseries(rec: TestRecord) -> pd.DataFrame | None:
    """Load a pressure-leak raw_data.csv (decay trace) into canonical names."""
    path = rec.raw_data_path
    if path is None or path.stat().st_size == 0:
        return None
    df = pd.read_csv(path)
    if df.empty:
        return None
    df = df.rename(columns={k: v for k, v in schema.RAW_PRESSURE_TO_CANONICAL.items()
                            if k in df.columns})
    if "time" in df.columns:
        df["time"] = pd.to_datetime(df["time"], utc=True, errors="coerce")
    for c in [c for c in df.columns if c != "time"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


# ---------------------------------------------------------------------------
# Scalar results — two formats, one canonical dict
# ---------------------------------------------------------------------------

# Electrolysis results: vertical (Metric, Value, Unit). Raw metric label -> canonical key.
_ELECTROLYSIS_RESULTS_MAP: dict[str, str] = {
    "Avg H₂ Purity in SS": "avg_h2_purity_ss",
    "Faradaic Eff in SS (Purity)": "faradaic_eff_ss",
    "Yield Efficiency": "yield_efficiency",
    "Total H₂ Production": "total_h2_g",
    "H₂ Header Yield": "h2_header_yield_g",
    "Theoretical H₂": "theoretical_h2_g",
    "Peak Temperature": "peak_temp_c",
    "Peak H₂ Purity": "peak_h2_purity",
    "Peak O₂ Purity": "peak_o2_purity",
    "Avg Current in SS (Purity)": "avg_current_ss",
    "Avg Cell Voltage in SS (Purity)": "avg_cell_voltage_ss",
    "Cell Count": "cell_count",
    "Run Time": "run_time_min",
    "Current Run Time": "current_run_time_min",
}

# Pressure results: horizontal (header + 1 row). Raw column -> canonical key.
_PRESSURE_RESULTS_MAP: dict[str, str] = {
    "Abs Leak Rate (psi/min)": "abs_leak_rate",
    "Diff Leak Rate (psi/min)": "diff_leak_rate",
    "Max Diff Pressure (psi)": "max_diff_pressure",
    "Max Header A Pressure (psi)": "max_header_a",
    "Max Header B Pressure (psi)": "max_header_b",
    "Tau (s)": "tau_s",
    "R2 Abs Decay": "r2_abs_decay",
    "P0 Fitted (psi)": "p0_fitted",
    "P-inf Fitted (psi)": "pinf_fitted",
    "Stack Mass (kg)": "stack_mass_kg",
    "Stack Resistance (Ω)": "stack_resistance_ohm",
    "Cell Count": "cell_count",
}


# Which test type sources each scalar key (used by scalar_vs_scalar joining).
ELECTROLYSIS_RESULTS_KEYS = frozenset(_ELECTROLYSIS_RESULTS_MAP.values())
PRESSURE_RESULTS_KEYS = frozenset(_PRESSURE_RESULTS_MAP.values())


def _to_float(value) -> float | None:
    """Coerce a results cell to float; non-numeric ('—', '', text) -> None."""
    try:
        f = float(str(value).strip())
    except (ValueError, AttributeError, TypeError):
        return None
    return f


def load_results(rec: TestRecord) -> dict[str, float]:
    """Load a test's scalar results into a flat {canonical_key: float} dict.

    Picks the parser by test type. Only numeric, registry-mapped fields are returned.
    Missing file -> empty dict.
    """
    path = rec.results_path
    if path is None or path.stat().st_size == 0:
        return {}

    if rec.test_type == "electrolysis":
        df = pd.read_csv(path)
        if not {"Metric", "Value"}.issubset(df.columns):
            return {}
        raw = dict(zip(df["Metric"], df["Value"]))
        mapping = _ELECTROLYSIS_RESULTS_MAP
    else:  # pressure
        df = pd.read_csv(path)
        if df.empty:
            return {}
        raw = df.iloc[0].to_dict()
        mapping = _PRESSURE_RESULTS_MAP

    out: dict[str, float] = {}
    for raw_label, canon in mapping.items():
        if raw_label in raw:
            f = _to_float(raw[raw_label])
            if f is not None:
                out[canon] = f
    return out


def get_cell_count(rec: TestRecord) -> int | None:
    """Cell count for a test (needed for per-cell voltage). None if unavailable."""
    cc = load_results(rec).get("cell_count")
    return int(cc) if cc is not None else None


# ---------------------------------------------------------------------------
# IV curves
# ---------------------------------------------------------------------------

def load_derived(rec: TestRecord) -> pd.DataFrame | None:
    """Load a test's time series WITH derived columns added (the per-test load-once path).

    Honors config.USE_CACHE: persists the derived frame to feather and reuses it on later
    runs when fresher than the source CSV. Cache is best-effort — any failure (e.g. no
    pyarrow) silently falls back to recomputation.
    """
    raw = rec.raw_data_path
    if raw is None:
        return None

    cache_path = config.CACHE_ROOT / f"SN{rec.stack:04d}_ID{rec.test_id}_derived.feather"
    if config.USE_CACHE and cache_path.exists() and cache_path.stat().st_mtime >= raw.stat().st_mtime:
        try:
            return pd.read_feather(cache_path)
        except Exception:
            pass

    df = load_timeseries(rec)
    if df is None:
        return None
    dd = derived.add_derived_columns(df, get_cell_count(rec))

    if config.USE_CACHE:
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            dd.to_feather(cache_path)
        except Exception:
            pass
    return dd


def load_iv_curves(rec: TestRecord) -> list[pd.DataFrame]:
    """Load all iv_curve_*.csv for a test as DataFrames with columns I, V, T."""
    if not rec.iv_dir.is_dir():
        return []
    out = []
    for path in sorted(rec.iv_dir.glob("*_iv_curve_*.csv")):
        df = pd.read_csv(path)
        for c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
        out.append(df.dropna(how="all"))
    return out
