"""Registry of plottable variables.

Single source of truth for a variable's human label and unit, keyed by canonical name.
Chart code looks up labels here so axis labels and legends are always consistent and
never hand-typed at call sites.

Two registries:
  TIMESERIES_VARS  - per-sample quantities (raw or derived) that live in the time-series
                     DataFrame. Plottable on series_vs_time and timeseries_scatter.
  SCALAR_VARS      - one-value-per-test quantities (from results files or reduced from a
                     time series). Plottable on scalar_vs_scalar.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Variable:
    name: str           # canonical key
    label: str          # human-readable, used in titles/legends
    unit: str           # unit string ("" if dimensionless)
    source: str         # "raw" | "derived" | "results" | "reduced"

    def axis_label(self) -> str:
        return f"{self.label} ({self.unit})" if self.unit else self.label


def _reg(items: list[Variable]) -> dict[str, Variable]:
    return {v.name: v for v in items}


# ---------------------------------------------------------------------------
# Time-series variables
# ---------------------------------------------------------------------------

TIMESERIES_VARS: dict[str, Variable] = _reg([
    # --- raw (post canonical-rename) ---
    Variable("time", "Time", "", "raw"),
    Variable("stack_temp_C", "Stack Temperature", "°C", "raw"),
    Variable("O2_purity_pct", "O₂ Purity", "%", "raw"),
    Variable("H2_purity_pct", "H₂ Purity", "%", "raw"),
    Variable("current_A", "Current", "A", "raw"),
    Variable("voltage_V", "Stack Voltage", "V", "raw"),
    Variable("O2_flow_SLPM", "O₂ Flow", "SLPM", "raw"),
    Variable("H2_flow_SLPM", "H₂ Flow", "SLPM", "raw"),
    Variable("H2_pressure_PSIG", "H₂ Pressure", "PSIG", "raw"),
    Variable("O2_pressure_PSIG", "O₂ Pressure", "PSIG", "raw"),
    Variable("H2_captured_SLPM", "H₂ Captured (H₂ stream)", "SLPM", "raw"),
    Variable("H2_total_SLPM", "H₂ Total Produced", "SLPM", "raw"),
    Variable("H2_theoretical_SLPM", "H₂ Theoretical", "SLPM", "raw"),
    Variable("O2_captured_SLPM", "O₂ Captured (O₂ stream)", "SLPM", "raw"),
    Variable("O2_total_SLPM", "O₂ Total Produced", "SLPM", "raw"),
    Variable("O2_theoretical_SLPM", "O₂ Theoretical", "SLPM", "raw"),
    Variable("eta_H2", "Faradaic Efficiency (H₂)", "fraction", "raw"),
    Variable("mdot_H2_gps", "H₂ Mass Rate", "g/s", "raw"),
    # --- derived (added by derived.add_derived_columns) ---
    Variable("dP_H2_O2_PSIG", "Differential Pressure (H₂−O₂)", "PSIG", "derived"),
    Variable("H2_impurity_pct", "H₂-Stream Impurity (O₂-in-H₂)", "%", "derived"),
    Variable("O2_impurity_pct", "O₂-Stream Impurity (H₂-in-O₂)", "%", "derived"),
    Variable("H2_capture_efficiency", "H₂ Capture Efficiency", "fraction", "derived"),
    Variable("O2_capture_efficiency", "O₂ Capture Efficiency", "fraction", "derived"),
    Variable("H2_crossover_SLPM", "H₂ Crossover (to O₂ side)", "SLPM", "derived"),
    Variable("O2_crossover_SLPM", "O₂ Crossover (to H₂ side)", "SLPM", "derived"),
    Variable("cell_voltage_V", "Per-Cell Voltage", "V", "derived"),
    Variable("power_W", "Stack Power", "W", "derived"),
    Variable("eta_O2", "Faradaic Efficiency (O₂)", "fraction", "derived"),
    Variable("specific_energy_kWh_per_kg", "Specific Energy", "kWh/kg H₂", "derived"),
    Variable("flow_ratio_H2_O2", "H₂:O₂ Flow Ratio", "", "derived"),
    Variable("apparent_resistance_ohm", "Apparent Stack Resistance", "Ω", "derived"),
    Variable("O2_purity_safety_margin_pct", "O₂ Purity Safety Margin", "%", "derived"),
])


# ---------------------------------------------------------------------------
# Scalar variables (one value per test)
# ---------------------------------------------------------------------------

SCALAR_VARS: dict[str, Variable] = _reg([
    # --- reduced from electrolysis time series (current-flowing window) ---
    Variable("avg_h2_purity_running", "Avg H₂ Purity (running)", "%", "reduced"),
    Variable("avg_o2_purity_running", "Avg O₂ Purity (running)", "%", "reduced"),
    Variable("avg_h2_impurity_running", "Avg H₂ Impurity (running)", "%", "reduced"),
    Variable("avg_o2_impurity_running", "Avg O₂ Impurity (running)", "%", "reduced"),
    Variable("avg_h2_capture_eff_running", "Avg H₂ Capture Eff (running)", "fraction", "reduced"),
    Variable("avg_o2_capture_eff_running", "Avg O₂ Capture Eff (running)", "fraction", "reduced"),
    Variable("avg_dp_running", "Avg Differential Pressure (running)", "PSIG", "reduced"),
    Variable("avg_temp_running", "Avg Stack Temp (running)", "°C", "reduced"),
    Variable("peak_temp_running", "Peak Stack Temp (running)", "°C", "reduced"),
    Variable("avg_current_running", "Avg Current (running)", "A", "reduced"),
    Variable("avg_voltage_running", "Avg Stack Voltage (running)", "V", "reduced"),
    Variable("avg_cell_voltage_running", "Avg Per-Cell Voltage (running)", "V", "reduced"),
    Variable("avg_eta_h2_running", "Avg Faradaic Eff H₂ (running)", "fraction", "reduced"),
    Variable("avg_power_running", "Avg Stack Power (running)", "W", "reduced"),
    Variable("avg_specific_energy_running", "Avg Specific Energy (running)", "kWh/kg H₂", "reduced"),
    Variable("total_h2_produced_g_integral", "Total H₂ Produced (∫ mdot)", "g", "reduced"),
    # --- straight from electrolysis results file ---
    Variable("avg_h2_purity_ss", "Avg H₂ Purity in SS", "%", "results"),
    Variable("faradaic_eff_ss", "Faradaic Eff in SS", "%", "results"),
    Variable("yield_efficiency", "Yield Efficiency", "%", "results"),
    Variable("total_h2_g", "Total H₂ Production", "g", "results"),
    Variable("h2_header_yield_g", "H₂ Header Yield", "g", "results"),
    Variable("theoretical_h2_g", "Theoretical H₂", "g", "results"),
    Variable("peak_temp_c", "Peak Temperature", "°C", "results"),
    Variable("peak_h2_purity", "Peak H₂ Purity", "%", "results"),
    Variable("peak_o2_purity", "Peak O₂ Purity", "%", "results"),
    Variable("avg_current_ss", "Avg Current in SS", "A", "results"),
    Variable("avg_cell_voltage_ss", "Avg Cell Voltage in SS", "V", "results"),
    Variable("cell_count", "Cell Count", "", "results"),
    Variable("run_time_min", "Run Time", "min", "results"),
    Variable("current_run_time_min", "Current Run Time", "min", "results"),
    # --- straight from pressure results file ---
    Variable("abs_leak_rate", "Abs Leak Rate", "psi/min", "results"),
    Variable("diff_leak_rate", "Diff Leak Rate", "psi/min", "results"),
    Variable("max_diff_pressure", "Max Diff Pressure", "psi", "results"),
    Variable("max_header_a", "Max Header A Pressure", "psi", "results"),
    Variable("max_header_b", "Max Header B Pressure", "psi", "results"),
    Variable("tau_s", "Decay Tau", "s", "results"),
    Variable("r2_abs_decay", "R² Abs Decay", "", "results"),
    Variable("p0_fitted", "P₀ Fitted", "psi", "results"),
    Variable("pinf_fitted", "P∞ Fitted", "psi", "results"),
    Variable("stack_mass_kg", "Stack Mass", "kg", "results"),
    Variable("stack_resistance_ohm", "Stack Resistance", "Ω", "results"),
])


# ---------------------------------------------------------------------------
# Lookup helpers — used everywhere instead of hand-typed labels.
# ---------------------------------------------------------------------------

def get(name: str) -> Variable:
    if name in TIMESERIES_VARS:
        return TIMESERIES_VARS[name]
    if name in SCALAR_VARS:
        return SCALAR_VARS[name]
    raise KeyError(f"Unknown variable: {name!r}")


def axis_label(name: str) -> str:
    return get(name).axis_label()


def label(name: str) -> str:
    return get(name).label
