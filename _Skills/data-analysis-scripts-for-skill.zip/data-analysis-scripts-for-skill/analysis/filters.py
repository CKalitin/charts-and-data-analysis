"""Boolean row masks for time-series filtering.

The rig's documented flag columns (`current_flowing`, `iv_curve_active`) are NOT present
in the exported raw data, so we derive what we can:

  - current_flowing  -> derived from Current_A >= threshold (documented 1 A).
  - iv_curve_active  -> NOT recoverable from raw data; the mask is a no-op (all-False)
                        unless a column ever appears. Documented as best-effort.

`apply_filter` resolves the named default in config into a concrete mask.
"""

from __future__ import annotations

import pandas as pd

from . import config


def current_flowing_mask(df: pd.DataFrame) -> pd.Series:
    """True where stack current >= threshold. False (not NaN) elsewhere."""
    if "current_A" not in df.columns:
        return pd.Series(True, index=df.index)
    return df["current_A"] >= config.CURRENT_FLOW_THRESHOLD_A


def iv_sweep_mask(df: pd.DataFrame) -> pd.Series:
    """True where an IV sweep was active. Best-effort: all-False unless a flag exists."""
    if "iv_curve_active" in df.columns:
        return df["iv_curve_active"].astype("boolean").fillna(False)
    return pd.Series(False, index=df.index)


def apply_filter(df: pd.DataFrame, name: str | None = None) -> pd.Series:
    """Return the row mask for a named filter (defaults to config.DEFAULT_TS_FILTER)."""
    name = name or config.DEFAULT_TS_FILTER
    if name == "none":
        return pd.Series(True, index=df.index)
    if name == "drop_iv_only":
        return ~iv_sweep_mask(df)
    if name == "require_current":
        return current_flowing_mask(df) & ~iv_sweep_mask(df)
    raise ValueError(f"Unknown filter: {name!r}")
