"""Axis display-range policy — a small value type, deliberately logic-only.

A chart axis can pick its visible limits three ways:

  - ``full``     show everything; let matplotlib autoscale (the default).
  - ``autoclip`` clip to data percentiles (+ a little padding). Tames a cluster of
                 outliers that would otherwise compress the region of interest — a
                 "soft" focus on the dense body of the data.
  - ``manual``   hard-coded limits; either side may be ``None`` to autoscale that side.

This module knows nothing about which variable/chart a policy applies to — that mapping
lives in ``config.py`` (so config can import this leaf without a cycle). The only behavior
here is turning a policy + the plotted data into concrete ``(lo, hi)`` axis limits.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np

AxisMode = Literal["full", "autoclip", "manual"]


@dataclass(frozen=True)
class AxisRange:
    """How one axis chooses its limits. Construct via the classmethods, not the fields."""

    mode: AxisMode = "full"
    lo: float | None = None          # manual: lower limit (None -> autoscale this side)
    hi: float | None = None          # manual: upper limit (None -> autoscale this side)
    lo_pct: float = 1.0              # autoclip: lower percentile
    hi_pct: float = 99.0             # autoclip: upper percentile
    pad_frac: float = 0.05           # autoclip: pad each side by this fraction of the span

    # -- constructors (the readable, validated API) -------------------------------------

    @classmethod
    def full(cls) -> "AxisRange":
        """Show all data (matplotlib autoscale)."""
        return cls(mode="full")

    @classmethod
    def autoclip(cls, *, lo_pct: float = 1.0, hi_pct: float = 99.0,
                 pad_frac: float = 0.05) -> "AxisRange":
        """Clip to the [lo_pct, hi_pct] percentile band of the plotted data, padded.

        Set ``hi_pct=100`` (or ``lo_pct=0``) to leave that tail unclipped — useful when
        the region you care about sits at one extreme (e.g. high H2 purity).
        """
        if not 0.0 <= lo_pct < hi_pct <= 100.0:
            raise ValueError(
                f"autoclip needs 0 <= lo_pct < hi_pct <= 100; got lo_pct={lo_pct}, hi_pct={hi_pct}")
        if pad_frac < 0.0:
            raise ValueError(f"pad_frac must be >= 0; got {pad_frac}")
        return cls(mode="autoclip", lo_pct=lo_pct, hi_pct=hi_pct, pad_frac=pad_frac)

    @classmethod
    def manual(cls, lo: float | None = None, hi: float | None = None) -> "AxisRange":
        """Hard-coded limits. Pass only one side to clip that side and autoscale the other."""
        if lo is None and hi is None:
            raise ValueError("manual range needs at least one of lo/hi")
        if lo is not None and hi is not None and lo >= hi:
            raise ValueError(f"manual range needs lo < hi; got lo={lo} >= hi={hi}")
        return cls(mode="manual", lo=lo, hi=hi)

    # -- resolution ---------------------------------------------------------------------

    def limits(self, data) -> tuple[float | None, float | None]:
        """Resolve to concrete ``(lo, hi)``. ``None`` on a side = autoscale that side.

        Returns ``(None, None)`` (i.e. no clipping) for ``full`` and for any degenerate
        autoclip case — empty data, all-NaN, or a constant series — so a policy can never
        collapse an axis to a single point.
        """
        if self.mode == "full":
            return (None, None)
        if self.mode == "manual":
            return (self.lo, self.hi)

        # autoclip
        arr = np.asarray(data, dtype="float64")
        arr = arr[np.isfinite(arr)]
        if arr.size == 0:
            return (None, None)
        lo = float(np.percentile(arr, self.lo_pct))
        hi = float(np.percentile(arr, self.hi_pct))
        if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
            return (None, None)
        pad = (hi - lo) * self.pad_frac
        return (lo - pad, hi + pad)
