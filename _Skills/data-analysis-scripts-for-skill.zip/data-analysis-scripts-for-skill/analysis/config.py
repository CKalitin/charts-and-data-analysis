"""Central configuration for the analysis framework.

Everything tunable lives here so scripts stay declarative. Grouped into:
  - Paths
  - Data selection (which stacks / tests)
  - Physics / filtering thresholds
  - Scalar-vs-scalar join strategy
  - Plot styling
  - Performance knobs (for the large sweeps)
  - Sweep enable-lists (which variables participate in raw_correlations)
"""

from __future__ import annotations

import os
from pathlib import Path

from .axis_range import AxisRange  # leaf value type; safe to import here (no cycle)

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent
RAW_DATA_ROOT = PROJECT_ROOT / "raw_data" / "Stack QC"
OUTPUT_ROOT = PROJECT_ROOT / "outputs"
CACHE_ROOT = PROJECT_ROOT / ".cache"  # derived-frame cache (feather), git-ignorable

# ---------------------------------------------------------------------------
# Data selection
# ---------------------------------------------------------------------------

# Stacks to include across all analyses (serial numbers as ints). None = all discovered.
STACKS: list[int] | None = [18, 19, 20]

# Global test-ID exclusions (applies to BOTH test types).
EXCLUDE_TEST_IDS: list[int] = []

# Per-stack test-ID exclusions, e.g. {18: [56]} to drop ID56 from SN0018 only.
EXCLUDE_TEST_IDS_BY_STACK: dict[int, list[int]] = {}

# ---------------------------------------------------------------------------
# Physics / filtering thresholds
# ---------------------------------------------------------------------------

# Stack is considered "running" (gas accounting valid) at/above this current.
# Documented threshold from the rig's report_gen (CURRENT_FLOW_THRESHOLD_A).
CURRENT_FLOW_THRESHOLD_A = 1.0

# Disconnected-thermocouple sentinel: open input reads this value.
TC_SENTINEL_C = 6453.6

# Default time-series filter applied by chart modules unless overridden:
#   "require_current"   -> keep rows with current_flowing (and drop IV sweeps if detectable)
#   "drop_iv_only"      -> drop IV-sweep rows only (keep idle/purge)
#   "none"              -> no filtering
DEFAULT_TS_FILTER = "require_current"

# ---------------------------------------------------------------------------
# Scalar-vs-scalar join strategy
# ---------------------------------------------------------------------------

# How a point is formed when an electrolysis test must be paired with a pressure test
# (they have independent IDs; a stack has several of each):
#   "every_pair"       -> cartesian product of electrolysis x pressure within a stack
#                         i.e. every (electrolysis ID, pressure ID) combo (DEFAULT)
#   "per_test_nearest" -> one point per electrolysis test, joined to nearest-in-time
#                         pressure test on the same stack
#   "per_stack_latest" -> one point per stack using each type's latest test
SCALAR_JOIN_STRATEGY = "every_pair"

# ---------------------------------------------------------------------------
# Scalar-chart point labels
# ---------------------------------------------------------------------------
#
# Annotation text for each point on a scalar_vs_scalar chart, assembled from named fields
# (see point_labels.FIELDS). Precedence (most specific wins):
#   POINT_LABEL_BY_CHART  >  POINT_LABEL_MIXED_FIELDS  >  POINT_LABEL_DEFAULT_FIELDS
# Available fields: pair_id, elec_id, pres_id, elec_date, pres_date, current_run_time, run_time.
# (Fields self-skip when their data is absent, so an unused one just drops out of the label.)

# Default for every scalar chart: just the test-ID pair (the prior behavior).
POINT_LABEL_DEFAULT_FIELDS: list[str] = ["pair_id"]

# Mixed electrolysis×pressure charts (either orientation): a point joins one of each test
# type, so carry both dates + current-on time. Applies to ALL such charts at once. Set to
# POINT_LABEL_DEFAULT_FIELDS (or []) to disable. Same-type charts are unaffected.
POINT_LABEL_MIXED_FIELDS: list[str] = ["pair_id", "elec_date", "pres_date", "current_run_time"]

# Per-chart overrides (most specific): keyed by the scalar pair (yvar, xvar), matching the
# chart title / output name "<yvar>_vs_<xvar>". Empty — the mixed tier above covers the
# electrolysis-vs-pressure family; add an entry here only to special-case one chart.
POINT_LABEL_BY_CHART: dict[tuple[str, str], list[str]] = {}

# ---------------------------------------------------------------------------
# Plot styling
# ---------------------------------------------------------------------------

FIGSIZE = (10, 6)
DPI = 150               # presentation-quality single charts
GRID = True
SCATTER_MARKER_SIZE = 14
LINE_WIDTH = 1.2

# Colormap used to encode elapsed time in the gradient panel of paired scatters.
TIME_GRADIENT_CMAP = "viridis"

# Qualitative palette for distinguishing series/stacks.
QUALITATIVE_PALETTE = "tab10"

# ---------------------------------------------------------------------------
# Axis display ranges
# ---------------------------------------------------------------------------
#
# How a plotted axis chooses its visible limits. Three modes (see axis_range.py):
#   AxisRange.full()                          show everything (matplotlib autoscale)
#   AxisRange.autoclip(lo_pct=, hi_pct=)      clip to data percentiles (+pad); tame outliers
#   AxisRange.manual(lo=, hi=)                hard-coded limits (either side may be None)
#
# A policy is looked up per axis with this precedence (most specific wins):
#   AXIS_RANGE_BY_CHART  >  AXIS_RANGE_BY_VAR  >  AXIS_RANGE_DEFAULT
# Currently consumed by the paired timeseries-scatter charts; wiring other chart types
# is a one-line call to plotting.apply_chart_axis_ranges (see plotting.py).

# Fallback for every axis with no more-specific entry below.
AXIS_RANGE_DEFAULT: AxisRange = AxisRange.full()

# Per-variable policy: applies wherever that variable lands on an axis. Empty = none.
# Use this when the clipping is intrinsic to the variable (it has the same outlier shape
# no matter what it's plotted against).
AXIS_RANGE_BY_VAR: dict[str, AxisRange] = {
    # eta_H2 (faradaic efficiency) is bounded ~[0,1] physically but sensor noise at low
    # current spikes it well past 1 (seen up to ~15), crushing the real body into a sliver.
    # Clip BOTH tails to the dense band on any chart where eta_H2 is an axis (e.g. every
    # "<var> vs eta_H2" scatter). Data-adaptive, so each test focuses on its own body.
    "eta_H2": AxisRange.autoclip(lo_pct=2, hi_pct=98),
}

# Per-chart policy (most specific): keyed by the scatter pair EXACTLY as the sweep forms it
# — (yvar, xvar), matching the output folder "<yvar>_vs_<xvar>". Value maps the axis
# ("x" / "y") you want to override; unlisted axes fall through to BY_VAR / DEFAULT.
AXIS_RANGE_BY_CHART: dict[tuple[str, str], dict[str, AxisRange]] = {
    # H2 purity vs dP: a cluster of low-purity outliers (<90%) compresses the 97%+ band we
    # actually care about. Autoclip the H2-purity (x) axis to its dense upper body; keep the
    # top (hi_pct=100) since high purity is the region of interest. Tune lo_pct if the low
    # cluster still shows (raise it) or good data gets cut (lower it).
    ("dP_H2_O2_PSIG", "H2_purity_pct"): {"x": AxisRange.autoclip(lo_pct=5, hi_pct=100)},
    ("H2_purity_pct", "dP_H2_O2_PSIG"): {"y": AxisRange.autoclip(lo_pct=5, hi_pct=100)},
}

# ---------------------------------------------------------------------------
# Performance knobs (matter for the thousands-of-charts sweeps)
# ---------------------------------------------------------------------------

# Worker processes for the raw-correlations sweep. Default: leave one core free.
N_WORKERS = max(1, (os.cpu_count() or 2) - 1)

# Lower DPI for the bulk sweep — raster cost scales ~DPI^2.
BULK_DPI = 90

# Decimate dense time-series scatters to at most this many points (uniform stride).
MAX_SCATTER_POINTS = 2000

# Reuse a single Figure per worker and clear it between charts (big win at scale).
FIGURE_REUSE = True

# Cache loaded+derived frames to feather so reruns skip CSV parsing.
USE_CACHE = True

# PNG zlib compression level for bulk output (0-9). Lower = faster, larger files.
BULK_PNG_COMPRESS_LEVEL = 1

# ---------------------------------------------------------------------------
# Sweep enable-lists — which canonical variables participate in raw_correlations.
# Narrow these to control combinatorial volume. Names must exist in variables.py.
# Empty list for an axis means "use the module's sensible default set".
# ---------------------------------------------------------------------------

# Paired-scatter sweep (timeseries_scatter): every X plotted against every Y.
# NOTE: these drive ONLY the x-vs-y scatter family, not series-vs-time.
SWEEP_TS_Y_VARS: list[str] = [
    "O2_purity_pct",
    "H2_purity_pct",
    "dP_H2_O2_PSIG",
    "O2_flow_SLPM",
]
SWEEP_TS_X_VARS: list[str] = [
    "dP_H2_O2_PSIG",
    "stack_temp_C",
    "H2_purity_pct",
    "H2_flow_SLPM",
    "O2_flow_SLPM",
    "eta_H2",
    "H2_capture_efficiency",
    "O2_capture_efficiency",
]

# Series-vs-time sweep: which variables get plotted against time.
# Independent of the scatter sweep above so debug-only channels (current, voltage)
# can appear vs time WITHOUT entering the x-vs-y scatter cartesian.
#   - SWEEP_SERIES_TIME_EXTRA_VARS: series-vs-time-only additions (e.g. debug channels)
#   - SWEEP_SERIES_TIME_VARS: the resolved full set (scatter vars ∪ extras); edit freely.
SWEEP_SERIES_TIME_EXTRA_VARS: list[str] = [
    "current_A",
    "voltage_V",
    "stack_temp_C",
]
SWEEP_SERIES_TIME_VARS: list[str] = sorted(
    set(SWEEP_TS_Y_VARS) | set(SWEEP_TS_X_VARS) | set(SWEEP_SERIES_TIME_EXTRA_VARS)
)

# Scalar sweep (scalar_vs_scalar):
SWEEP_SCALAR_Y_VARS: list[str] = [
    "avg_o2_purity_running",
    "avg_dp_running",
]
SWEEP_SCALAR_X_VARS: list[str] = [
    "diff_leak_rate",
    "abs_leak_rate",
    "avg_h2_capture_eff_running",
    "avg_eta_h2_running",
]
