"""Headless rendering layer — the one place matplotlib is configured.

Uses the object-oriented Agg API (no pyplot) for speed and process-safety, sets all
rcParams once at import, and provides:
  - new_figure()        : a fresh single-axes Figure (use for one-off / colorbar charts)
  - ReusableFigure      : a Figure held open and cleared between charts (bulk sweep)
  - save_fig()          : mkdir + savefig on a cheap path (no bbox='tight')

Chart modules draw onto a provided Axes so the same code works for both one-off and
reused figures.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # headless, fork/spawn-safe; must precede figure imports

from matplotlib.backends.backend_agg import FigureCanvasAgg  # noqa: E402
from matplotlib.figure import Figure  # noqa: E402

from . import config  # noqa: E402

# Configure style ONCE — never per figure.
matplotlib.rcParams.update({
    "figure.constrained_layout.use": True,   # cheaper + safer than per-figure tight_layout
    "axes.grid": config.GRID,
    "grid.linestyle": "--",
    "grid.alpha": 0.4,
    "font.size": 10,
    "legend.fontsize": 9,
    "savefig.bbox": None,                    # explicitly NOT 'tight' (avoids extra render pass)
})


def new_figure(figsize=None, dpi=None):
    """Create a fresh Figure + single Axes via the OO API. Returns (fig, ax)."""
    fig = Figure(figsize=figsize or config.FIGSIZE, dpi=dpi or config.DPI)
    FigureCanvasAgg(fig)
    ax = fig.add_subplot(1, 1, 1)
    return fig, ax


def save_fig(fig, path: Path | str, dpi: int | None = None,
             compress_level: int | None = None) -> Path:
    """Write `fig` to `path` (parents created). Cheap path: fixed layout, tuned PNG compression."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pil_kwargs = None
    if compress_level is not None and path.suffix.lower() == ".png":
        pil_kwargs = {"compress_level": compress_level}
    fig.savefig(path, dpi=dpi or config.DPI, pil_kwargs=pil_kwargs)
    return path


class ReusableFigure:
    """A single Figure reused across many charts (the per-worker performance pattern).

    Call `.axes()` to get a cleared Axes to draw on, then `.save(path)`. The Figure is
    never torn down, so allocation cost is paid once per worker.
    """

    def __init__(self, figsize=None, dpi=None):
        self.fig = Figure(figsize=figsize or config.FIGSIZE, dpi=dpi or config.BULK_DPI)
        FigureCanvasAgg(self.fig)
        self.ax = self.fig.add_subplot(1, 1, 1)
        self._dpi = dpi or config.BULK_DPI

    def axes(self):
        self.ax.cla()
        return self.ax

    def save(self, path: Path | str, compress_level: int | None = None) -> Path:
        return save_fig(self.fig, path, dpi=self._dpi,
                        compress_level=(config.BULK_PNG_COMPRESS_LEVEL
                                        if compress_level is None else compress_level))
