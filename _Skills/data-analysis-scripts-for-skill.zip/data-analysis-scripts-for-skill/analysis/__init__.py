"""Electrolyzer QC correlation-analysis framework.

Subpackages / modules:
    config      Central configuration (paths, thresholds, sweep enable-lists, perf knobs).
    schema      Raw -> canonical column naming, sentinel handling.
    loaders     Test discovery + pandas loaders (time series, both results formats, IV curves).
    variables   Registry of plottable variables (canonical name -> label/unit/kind).
    derived     Derived time-series columns + named scalar reducers.
    filters     Boolean masks (current-flowing, IV-sweep, steady-state).
    render      Headless Agg figure factory + reusable-figure context manager.
    plotting    General plotting primitives (one plot fn + annotation/const-line/gradient helpers).
    charts.*    Concrete chart types built on the above.

See README.md for the full architecture and the data model this is built around.
"""

__all__ = [
    "config",
    "schema",
    "loaders",
    "variables",
    "derived",
    "filters",
    "render",
    "plotting",
]
