"""Composable point-label fields for scalar_vs_scalar annotations.

A point on a scalar chart can carry a custom annotation assembled from named *fields*
(test IDs, test dates, run durations, …). Which fields a given chart uses is configured
in ``config.py`` (``POINT_LABEL_BY_CHART`` overrides ``POINT_LABEL_DEFAULT_FIELDS``), so
labels stay declarative and adding a new field is a one-function addition to ``FIELDS``.

Each field is a function ``(LabelContext) -> str | None``; returning ``None`` omits that
field (e.g. a date when the test has no parseable timestamp), so labels degrade cleanly.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from . import config
from .loaders import TestRecord

LabelField = Callable[["LabelContext"], "str | None"]  # None -> omit this field


@dataclass(frozen=True)
class LabelContext:
    """Everything a label field might need about one plotted point."""
    stack: int
    elec: TestRecord | None          # electrolysis test backing this point (if any)
    pres: TestRecord | None          # pressure test backing this point (if any)
    scalars: dict[str, float]        # merged scalar dict the point's x/y came from


# ---------------------------------------------------------------------------
# Field implementations — small, single-purpose; add new ones here.
# ---------------------------------------------------------------------------

def _date(rec: TestRecord | None) -> str | None:
    if rec is None or rec.start is None:
        return None
    return f"{rec.start:%b} {rec.start.day}"        # "Jun 3"


def _minutes(scalars: dict[str, float], key: str) -> str | None:
    v = scalars.get(key)
    if v is None or v != v:                          # missing or NaN
        return None
    return f"{v:.0f} min"


def pair_id(ctx: LabelContext) -> str | None:
    """`ID{e}×ID{p}` for a join, or the single `ID{n}` when only one side exists."""
    e, p = ctx.elec, ctx.pres
    if e and p:
        return f"ID{e.test_id}×ID{p.test_id}"
    if e:
        return f"ID{e.test_id}"
    if p:
        return f"ID{p.test_id}"
    return None


def elec_id(ctx: LabelContext) -> str | None:
    return f"ID{ctx.elec.test_id}" if ctx.elec else None


def pres_id(ctx: LabelContext) -> str | None:
    return f"ID{ctx.pres.test_id}" if ctx.pres else None


def elec_date(ctx: LabelContext) -> str | None:
    return _date(ctx.elec)


def pres_date(ctx: LabelContext) -> str | None:
    return _date(ctx.pres)


def current_run_time(ctx: LabelContext) -> str | None:
    """Time current was actually flowing in the electrolysis test (`current_run_time_min`)."""
    return _minutes(ctx.scalars, "current_run_time_min")


def run_time(ctx: LabelContext) -> str | None:
    """Total electrolysis run time (`run_time_min`)."""
    return _minutes(ctx.scalars, "run_time_min")


FIELDS: dict[str, LabelField] = {
    "pair_id": pair_id,
    "elec_id": elec_id,
    "pres_id": pres_id,
    "elec_date": elec_date,
    "pres_date": pres_date,
    "current_run_time": current_run_time,
    "run_time": run_time,
}


# ---------------------------------------------------------------------------
# Resolution + assembly.
# ---------------------------------------------------------------------------

def label_fields_for(yvar: str, xvar: str, *, mixed: bool = False) -> list[str]:
    """Field list for a chart.

    Precedence: POINT_LABEL_BY_CHART > POINT_LABEL_MIXED_FIELDS (when `mixed`, i.e. the chart
    joins an electrolysis scalar with a pressure scalar) > POINT_LABEL_DEFAULT_FIELDS.
    """
    by_chart = config.POINT_LABEL_BY_CHART.get((yvar, xvar))
    if by_chart is not None:
        return by_chart
    if mixed and config.POINT_LABEL_MIXED_FIELDS:
        return config.POINT_LABEL_MIXED_FIELDS
    return config.POINT_LABEL_DEFAULT_FIELDS


def format_label(ctx: LabelContext, field_names: list[str], *, sep: str = ", ") -> str:
    """Assemble a point label from the named fields, skipping any that return None."""
    parts: list[str] = []
    for name in field_names:
        fn = FIELDS.get(name)
        if fn is None:
            raise KeyError(f"unknown point-label field {name!r}; known: {sorted(FIELDS)}")
        s = fn(ctx)
        if s:
            parts.append(s)
    return sep.join(parts)
