"""Chart type: scalar vs scalar, one point per (SN, test).

Each point is one test (or a joined electrolysis+pressure pair). Because the two test
types have independent IDs and a stack has several of each, cross-type pairs are joined
per a configurable strategy (config.SCALAR_JOIN_STRATEGY):
  per_test_nearest  -> one point per electrolysis test, nearest-in-time pressure test (default)
  per_stack_latest  -> one point per stack, each type's latest test
  every_pair        -> cartesian electrolysis x pressure within a stack

When both axes are sourced from the same test type, no join is needed (one point per
test of that type).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import matplotlib

from .. import config, derived, filters, loaders, plotting, point_labels, variables
from ..loaders import TestRecord
from ..plotting import RefLine, TextBox


@dataclass
class _Point:
    stack: int
    label: str
    x: float
    y: float


def _scalar_source(name: str) -> str:
    """'electrolysis' | 'pressure' for a scalar key (cell_count treated as electrolysis)."""
    if name in loaders.PRESSURE_RESULTS_KEYS and name not in loaders.ELECTROLYSIS_RESULTS_KEYS:
        return "pressure"
    return "electrolysis"  # reduced + electrolysis-results + shared keys


def _electrolysis_scalars(rec: TestRecord) -> dict[str, float]:
    """Merged scalar dict for one electrolysis test: results file + running reductions."""
    out = dict(loaders.load_results(rec))
    df = loaders.load_timeseries(rec)
    if df is not None:
        dd = derived.add_derived_columns(df, loaders.get_cell_count(rec))
        out.update(derived.compute_running_scalars(dd, filters.apply_filter(dd)))
    return out


def _nearest(rec: TestRecord, candidates: list[TestRecord]) -> TestRecord | None:
    cands = [c for c in candidates if c.stack == rec.stack]
    if not cands:
        return None
    if rec.start is None:
        return cands[-1]
    return min(cands, key=lambda c: abs((c.start - rec.start).total_seconds())
               if c.start else float("inf"))


def collect_points(xvar: str, yvar: str, *, strategy: str | None = None,
                   tests: Sequence[TestRecord] | None = None) -> list[_Point]:
    """Build the (stack, label, x, y) points for an x/y scalar pair under a join strategy."""
    strategy = strategy or config.SCALAR_JOIN_STRATEGY
    tests = list(tests) if tests is not None else loaders.discover_tests()
    elec = [t for t in tests if t.test_type == "electrolysis"]
    pres = [t for t in tests if t.test_type == "pressure"]

    need = {_scalar_source(xvar), _scalar_source(yvar)}
    fields = point_labels.label_fields_for(yvar, xvar, mixed=need == {"electrolysis", "pressure"})

    def mk(stack: int, elec_rec: TestRecord | None, pres_rec: TestRecord | None,
           scalars: dict[str, float]) -> _Point:
        ctx = point_labels.LabelContext(stack, elec_rec, pres_rec, scalars)
        return _Point(stack, point_labels.format_label(ctx, fields),
                      scalars.get(xvar, float("nan")), scalars.get(yvar, float("nan")))

    points: list[_Point] = []

    if need == {"electrolysis"}:
        for t in elec:
            points.append(mk(t.stack, t, None, _electrolysis_scalars(t)))
    elif need == {"pressure"}:
        for t in pres:
            points.append(mk(t.stack, None, t, loaders.load_results(t)))
    else:  # mixed -> join electrolysis with pressure
        if strategy == "per_stack_latest":
            stacks = sorted({t.stack for t in elec} & {t.stack for t in pres})
            for sn in stacks:
                e = [t for t in elec if t.stack == sn][-1]
                p = [t for t in pres if t.stack == sn][-1]
                points.append(mk(sn, e, p, {**_electrolysis_scalars(e), **loaders.load_results(p)}))
        elif strategy == "every_pair":
            for e in elec:
                es = _electrolysis_scalars(e)
                for p in [t for t in pres if t.stack == e.stack]:
                    points.append(mk(e.stack, e, p, {**es, **loaders.load_results(p)}))
        else:  # per_test_nearest (default)
            for e in elec:
                p = _nearest(e, pres)
                merged = dict(_electrolysis_scalars(e))
                if p is not None:
                    merged.update(loaders.load_results(p))
                points.append(mk(e.stack, e, p, merged))

    return [pt for pt in points if pt.x == pt.x and pt.y == pt.y]  # drop NaN


def draw_scalar_vs_scalar(ax, xvar: str, yvar: str, *,
                          strategy: str | None = None,
                          tests: Sequence[TestRecord] | None = None,
                          annotate: bool = False,
                          title: str | None = None,
                          ref_lines: Sequence[RefLine] = (),
                          textboxes: Sequence[TextBox] = ()) -> bool:
    """Draw the scatter, one color per stack. Returns False if no points."""
    points = collect_points(xvar, yvar, strategy=strategy, tests=tests)
    if not points:
        return False

    cmap = matplotlib.colormaps[config.QUALITATIVE_PALETTE]
    stacks = sorted({p.stack for p in points})
    series = []
    for i, sn in enumerate(stacks):
        pts = [p for p in points if p.stack == sn]
        series.append(plotting.SeriesSpec(
            x=[p.x for p in pts], y=[p.y for p in pts],
            label=f"SN{sn:04d}", kind="scatter", color=cmap(i % cmap.N),
        ))
    plotting.draw(ax, series, xlabel=variables.axis_label(xvar),
                  ylabel=variables.axis_label(yvar), title=title,
                  ref_lines=ref_lines, textboxes=textboxes, legend=True)

    if annotate:
        for p in points:
            ax.annotate(p.label, (p.x, p.y),
                        fontsize=7, xytext=(3, 3), textcoords="offset points")
    return True
