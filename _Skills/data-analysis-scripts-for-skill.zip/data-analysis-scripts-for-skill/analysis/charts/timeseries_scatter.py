"""Chart type: time-paired x-vs-y scatter, colored by elapsed time.

Each point is a pair of values sampled at the SAME timestamp (x and y come from the same
rows of one test's time series). The default output is a SINGLE panel: a scatter colored by
ELAPSED TIME via a gradient colormap + colorbar — a way to encode time without a 3rd axis.

────────────────────────────────────────────────────────────────────────────────────────
DESIGN PRINCIPLE — panels are built independently; the combiner is intentionally dumb.
Each panel is produced by a self-contained *builder* closure `build(ax, fig)` that fully
styles its own Axes (labels, reference lines, text boxes, notes). The default convenience
(`paired_timeseries_scatter`) renders just the gradient builder onto a single-axes figure.

Multi-panel composition remains available for future use via `combine()`, which only lays
out subplots and calls the builders — it exposes NO styling parameters, so there is nothing
you can add to the "combined" object; ALL customization must happen inside a panel builder
(via the `*_panel_builder` constructors below). `combine(..., post_combine_hook=fn)` is a
cross-panel escape hatch — use sparingly.

Why build-onto-provided-Axes rather than rendering separate figures and pasting them:
matplotlib cannot cleanly move a rendered Axes between Figures, so `build(ax, fig)` is the
correct way to keep each panel's styling fully encapsulated while sharing one output canvas.
────────────────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

from pathlib import Path
from typing import Callable, Sequence

import numpy as np
import pandas as pd

from .. import config, plotting, render, variables
from ..plotting import RefLine, TextBox

PanelBuilder = Callable[[object, object], None]  # build(ax, fig) -> None


def _paired_xy(df: pd.DataFrame, xvar: str, yvar: str, mask):
    """Return decimated (x, y, elapsed_seconds) arrays for valid same-timestamp pairs."""
    cols = [c for c in (xvar, yvar, "time") if c in df.columns]
    if xvar not in df.columns or yvar not in df.columns:
        return None
    sub = df[mask] if mask is not None else df
    sub = sub[cols].dropna(subset=[xvar, yvar])
    if sub.empty:
        return None
    if "time" in sub.columns and sub["time"].notna().any():
        # .dt.total_seconds() is resolution-agnostic (timestamps here are us, not ns).
        elapsed = (sub["time"] - sub["time"].min()).dt.total_seconds().to_numpy()
    else:
        elapsed = np.arange(len(sub), dtype="float64")
    x = sub[xvar].to_numpy(dtype="float64")
    y = sub[yvar].to_numpy(dtype="float64")
    # Decimate dense traces (uniform stride) for speed at scale.
    n = len(x)
    if n > config.MAX_SCATTER_POINTS:
        stride = int(np.ceil(n / config.MAX_SCATTER_POINTS))
        x, y, elapsed = x[::stride], y[::stride], elapsed[::stride]
    return x, y, elapsed


# ---------------------------------------------------------------------------
# Panel builder constructors — ALL per-panel customization lives here.
# ---------------------------------------------------------------------------

def standard_panel_builder(x, y, xvar: str, yvar: str, *,
                           color=None, title: str | None = None,
                           ref_lines: Sequence[RefLine] = (),
                           textboxes: Sequence[TextBox] = ()) -> PanelBuilder:
    def build(ax, fig):
        plotting.draw(
            ax, [plotting.SeriesSpec(x=x, y=y, kind="scatter", color=color)],
            xlabel=variables.axis_label(xvar), ylabel=variables.axis_label(yvar),
            title=title, ref_lines=ref_lines, textboxes=textboxes, legend=False,
        )
        plotting.apply_chart_axis_ranges(ax, xvar=xvar, yvar=yvar, x=x, y=y)
    return build


def gradient_panel_builder(x, y, elapsed, xvar: str, yvar: str, *,
                           cmap: str | None = None, title: str | None = None,
                           ref_lines: Sequence[RefLine] = (),
                           textboxes: Sequence[TextBox] = ()) -> PanelBuilder:
    def build(ax, fig):
        mappable = plotting.gradient_scatter(ax, x, y, elapsed, cmap=cmap)
        cbar = fig.colorbar(mappable, ax=ax)
        cbar.set_label("Elapsed time (s)")
        ax.set_xlabel(variables.axis_label(xvar))
        ax.set_ylabel(variables.axis_label(yvar))
        if title:
            ax.set_title(title)
        for ref in ref_lines:
            plotting.add_constant_line(ax, ref)
        for box in textboxes:
            plotting.add_textbox(ax, box)
        plotting.apply_chart_axis_ranges(ax, xvar=xvar, yvar=yvar, x=x, y=y)
    return build


# ---------------------------------------------------------------------------
# The intentionally featureless combiner.
# ---------------------------------------------------------------------------

def combine(out_path: Path | str, top: PanelBuilder, bottom: PanelBuilder, *,
            figsize=None, dpi: int | None = None,
            post_combine_hook: Callable | None = None) -> Path:
    """Lay out two stacked panels and save. NO styling args by design (see module docstring)."""
    figsize = figsize or (config.FIGSIZE[0], config.FIGSIZE[1] * 1.7)
    fig, _ = render.new_figure(figsize=figsize, dpi=dpi or config.DPI)
    fig.clf()
    ax_top, ax_bot = fig.subplots(2, 1)
    top(ax_top, fig)
    bottom(ax_bot, fig)
    if post_combine_hook is not None:  # escape hatch — use sparingly
        post_combine_hook(fig, (ax_top, ax_bot))
    return render.save_fig(fig, out_path, dpi=dpi or config.DPI)


# ---------------------------------------------------------------------------
# High-level convenience — what runners call.
# ---------------------------------------------------------------------------

def paired_timeseries_scatter(out_path: Path | str, df: pd.DataFrame, xvar: str, yvar: str, *,
                              mask=None, title: str | None = None,
                              ref_lines: Sequence[RefLine] = (),
                              textboxes: Sequence[TextBox] = (),
                              cmap: str | None = None,
                              dpi: int | None = None) -> Path | None:
    """Render the time-gradient scatter (single panel). Returns path, or None if no data."""
    paired = _paired_xy(df, xvar, yvar, mask)
    if paired is None:
        return None
    x, y, elapsed = paired
    build = gradient_panel_builder(x, y, elapsed, xvar, yvar, cmap=cmap, title=title,
                                   ref_lines=ref_lines, textboxes=textboxes)
    fig, ax = render.new_figure(dpi=dpi or config.DPI)
    build(ax, fig)
    return render.save_fig(fig, out_path, dpi=dpi or config.DPI)
