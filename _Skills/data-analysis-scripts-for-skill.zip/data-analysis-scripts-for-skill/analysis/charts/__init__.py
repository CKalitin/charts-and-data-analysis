"""Concrete chart types built on the analysis core + plotting primitives."""
