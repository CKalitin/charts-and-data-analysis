"""Chart type: variable(s) vs time (line plot) for a single test.

The straightforward case. Draws onto a provided Axes so it works with the reused-figure
sweep path. Default filter is applied unless overridden.
"""

from __future__ import annotations

from typing import Sequence

import pandas as pd

from .. import filters, plotting, variables
from ..plotting import RefLine, TextBox


def draw_var_vs_time(ax, df: pd.DataFrame, yvar: str, *,
                     filter_name: str | None = None,
                     label: str | None = None,
                     title: str | None = None,
                     ref_lines: Sequence[RefLine] = (),
                     textboxes: Sequence[TextBox] = ()) -> bool:
    """Draw one variable vs time. Returns False if there's nothing plottable."""
    if "time" not in df.columns or yvar not in df.columns:
        return False
    mask = filters.apply_filter(df, filter_name)
    sub = df[mask]
    series = [plotting.SeriesSpec(x=sub["time"], y=sub[yvar], label=label or variables.label(yvar))]
    if not sub[yvar].notna().any():
        return False
    plotting.draw(
        ax, series,
        xlabel="Time",
        ylabel=variables.axis_label(yvar),
        title=title,
        ref_lines=ref_lines,
        textboxes=textboxes,
        legend=label is not None,
    )
    return True


def draw_multi_var_vs_time(ax, df: pd.DataFrame, yvars: Sequence[str], *,
                           filter_name: str | None = None,
                           title: str | None = None,
                           ref_lines: Sequence[RefLine] = (),
                           textboxes: Sequence[TextBox] = ()) -> bool:
    """Overlay several variables vs time on one axis (caller ensures unit compatibility)."""
    present = [v for v in yvars if v in df.columns]
    if "time" not in df.columns or not present:
        return False
    mask = filters.apply_filter(df, filter_name)
    sub = df[mask]
    series = [plotting.SeriesSpec(x=sub["time"], y=sub[v], label=variables.label(v))
              for v in present if sub[v].notna().any()]
    if not series:
        return False
    units = {variables.get(v).unit for v in present}
    ylabel = variables.axis_label(present[0]) if len(units) == 1 else "Value"
    plotting.draw(ax, series, xlabel="Time", ylabel=ylabel, title=title,
                  ref_lines=ref_lines, textboxes=textboxes, legend=True)
    return True
