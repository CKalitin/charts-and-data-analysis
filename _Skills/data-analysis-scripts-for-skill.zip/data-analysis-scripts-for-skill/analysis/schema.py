"""Canonical naming layer.

The raw time-series CSVs use hardware-numbered columns whose numbering is a labeling
trap (BGA01 is O2, BGA02 is H2, etc.). EVERYTHING downstream uses canonical names so a
chart can never be silently mislabeled. This module owns that mapping and the
sentinel/format quirks.
"""

from __future__ import annotations

# Folder names for the two test types under each SN directory.
TEST_TYPE_PRESSURE = "01 Pressure Leak Test"
TEST_TYPE_ELECTROLYSIS = "02 Electrolysis Benchtop Test"

# Raw time-series column -> canonical name.
# NOTE the hardware-number -> gas mapping (verified against column_definitions.csv):
#   BGA01 = O2 purity, BGA02 = H2 purity
#   MFM01 = O2 flow,   MFM02 = H2 flow
#   PT01  = H2 pressure, PT02 = O2 pressure
#   TC05  = main stack temperature (TC06-16 disconnected; TC01-04 undocumented)
RAW_TO_CANONICAL: dict[str, str] = {
    "timestamp (PDT)": "time",
    "TC05": "stack_temp_C",
    "BGA01_pct": "O2_purity_pct",
    "BGA02_pct": "H2_purity_pct",
    "Current_A": "current_A",
    "Voltage_V": "voltage_V",
    "MFM01_SLPM": "O2_flow_SLPM",
    "MFM02_SLPM": "H2_flow_SLPM",
    "PT01_PSIG": "H2_pressure_PSIG",
    "PT02_PSIG": "O2_pressure_PSIG",
    "Q_H2_in_H2s_SLPM": "H2_captured_SLPM",
    "Q_H2_total_SLPM": "H2_total_SLPM",
    "Q_H2_th_SLPM": "H2_theoretical_SLPM",
    "Q_O2_in_O2s_SLPM": "O2_captured_SLPM",
    "Q_O2_total_SLPM": "O2_total_SLPM",
    "Q_O2_th_SLPM": "O2_theoretical_SLPM",
    "eta_H2": "eta_H2",
    "mdot_H2_gps": "mdot_H2_gps",
}

# Columns we intentionally drop from raw time series (disconnected / undocumented TCs).
# TC05 is kept (mapped above); the rest of TC01-16 are dropped.
DROP_RAW_COLUMNS: set[str] = {
    f"TC{n:02d}" for n in range(1, 17)
} - {"TC05"}

# Raw pressure-test time-series column -> canonical name (separate, smaller schema).
RAW_PRESSURE_TO_CANONICAL: dict[str, str] = {
    "time_utc": "time",
    "PT1_pressure_psi": "header_a_pressure_psi",  # see test Notes: A=O2 side / drain
    "PT2_pressure_psi": "header_b_pressure_psi",  # B=H2 side / fill
    "PT1_current_mA": "pt1_current_mA",
    "PT2_current_mA": "pt2_current_mA",
}


def canonical_timeseries_columns(raw_columns: list[str]) -> dict[str, str]:
    """Return the subset of {raw: canonical} renames present in `raw_columns`."""
    return {raw: canon for raw, canon in RAW_TO_CANONICAL.items() if raw in raw_columns}
