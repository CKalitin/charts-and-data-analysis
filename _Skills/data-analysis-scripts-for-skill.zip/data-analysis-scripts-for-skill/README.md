# data-analysis-1

Correlation-analysis framework for electrolyzer stack QC data.

The goal: take a handful of "important" variables and plot them against many others and
against time, across many stacks — potentially thousands of charts. This repo provides a
properly layered framework (canonical schema → loaders → derived variables → general
plotting → chart types) plus runners that sweep variable combinations.

---

## Quick start

```powershell
# Dry run — print planned chart count, render nothing
python scripts/run_raw_correlations.py --count

# Full sweep (all chart types, multiprocess)
python scripts/run_raw_correlations.py

# Individual chart families
python scripts/run_series_vs_time.py
python scripts/run_scalar_vs_scalar.py
python scripts/run_timeseries_scatter.py

# Subset of families in the full sweep
python scripts/run_raw_correlations.py --types series scatter
python scripts/run_raw_correlations.py --types scalar

# Single process (slower, useful for debugging)
python scripts/run_raw_correlations.py --serial

# IV curves (standalone, predates the framework)
python scripts/plot_iv_curves.py
```

Output lands in `outputs/raw_correlations/<chart_type>/<y>_vs_<x>/` for the sweep,
or `outputs/<chart_type>/` for individual runners. Start with `--count` before a full run.

---

## Repo layout

```
data-analysis-1/
├── raw_data/Stack QC/        # source data, never written to (see "Data model")
├── analysis/                 # the framework (importable package)
│   ├── config.py             # ALL tunables: stacks, excludes, thresholds, sweep sets, perf knobs
│   ├── schema.py             # raw → canonical column naming (the labeling-trap firewall)
│   ├── loaders.py            # test discovery + pandas loaders (both results formats, IV, cache)
│   ├── variables.py          # variable registry: canonical name → label/unit/source
│   ├── derived.py            # derived time-series columns + scalar reducers
│   ├── filters.py            # row masks (current-flowing, IV-sweep, steady-state)
│   ├── render.py             # headless Agg figure factory + reusable-figure (perf)
│   ├── plotting.py           # ONE general draw fn + const-lines/textboxes/notes/gradient
│   └── charts/
│       ├── series_vs_time.py
│       ├── scalar_vs_scalar.py
│       └── timeseries_scatter.py    # paired scatter w/ enforced independent panels
├── scripts/                  # runnable entry points (thin; all logic lives in analysis/)
│   ├── plot_iv_curves.py            # standalone IV-curve plotter (predates the framework)
│   ├── run_series_vs_time.py
│   ├── run_scalar_vs_scalar.py
│   ├── run_timeseries_scatter.py
│   └── run_raw_correlations.py      # the full sweep (multiprocess)
├── outputs/                  # generated artifacts — safe to delete & regenerate
└── .cache/                   # optional feather cache of derived frames (USE_CACHE)
```

**Convention:** nothing writes into `raw_data/`. All generated output lives under `outputs/`.
**Convention:** every tunable lives in `analysis/config.py` (or the config block atop a
standalone script) — never hardcoded at a call site.

---

## Data model (`raw_data/Stack QC/`)

Organization is **stack → test type → test ID**:

```
SN{stack:04d}/                                    # SN0018, SN0019, …
├── 01 Pressure Leak Test/
│   └── ID{id}_SN{stack}_{date}_{time}_PDT/
│       ├── ID..._raw_data.csv         # decay trace: PT1/PT2 pressure + current
│       └── ID..._test_results.csv     # HORIZONTAL: header row + one data row
└── 02 Electrolysis Benchtop Test/
    └── ID{id}_SN{stack}_{date}_{time}_PDT/
        ├── ID..._raw_data.csv         # time series (~33 cols, 1 Hz aggregated)
        ├── ID..._test_results.csv     # VERTICAL: Metric, Value, Unit (one per row)
        ├── column_definitions.csv
        └── IV Curves/ID..._iv_curve_{N}.csv      # columns: I,V,T
```

Things the framework had to be built around — read these before changing loaders:

- **Two test types, two independent ID counters.** Electrolysis IDs (~56–63) and Pressure
  IDs (~133–141) are separate ranges. Within a test type the ID counts up **globally across
  stacks**, not per stack — ID57 is SN0019 while ID56/61/62/63 are SN0018. The owning stack
  is the parent `SN{xxxx}/` folder, not inferable from the ID.
- **Hardware-numbered columns are a labeling trap.** In the raw time series:
  `BGA01`=**O₂** purity, `BGA02`=**H₂** purity; `MFM01`=**O₂** flow, `MFM02`=**H₂** flow;
  `PT01`=**H₂** pressure, `PT02`=**O₂** pressure. Everything goes through `schema.py`'s
  canonical rename so a chart can never be silently mislabeled.
- **Two different results formats.** Electrolysis results are vertical (Metric/Value/Unit
  per row); pressure results are horizontal (header + one row). `loaders.load_results`
  dispatches by test type and returns one flat `{canonical_key: float}` dict either way.
- **Documented flag columns are absent from the data.** `current_flowing` and
  `iv_curve_active` are described in `column_definitions.csv` but do **not** appear in the
  exported CSVs. So `current_flowing` is **derived** (`Current_A ≥ 1.0`), and IV-sweep
  exclusion is **best-effort** — a no-op unless the column ever appears (see `filters.py`).
- **Gas-accounting columns are blank when `Current_A < 1 A`** (`Q_*`, `eta_H2`, `mdot_*`).
  Reduce these over the current-flowing window only.
- **Partial/empty tests exist** (e.g. an electrolysis dir with no `raw_data.csv`, or with
  data but no IV curve). Loaders return `None`/empty and the sweep skips gracefully.
- **Thermocouples:** TC05 = main stack temperature (canonical `stack_temp_C`). TC06–16 are
  disconnected (sentinel `6453.6 °C`, scrubbed to NaN); TC01–04 are undocumented and dropped.
- **Timestamps are microsecond-resolution** (`datetime64[us, UTC]`). Compute elapsed time
  with `.dt.total_seconds()`, never by dividing a raw int64 by a hardcoded `1e9`.

---

## Canonical schema (`schema.py`)

| raw column          | canonical            | raw column            | canonical              |
|---------------------|----------------------|-----------------------|------------------------|
| `timestamp (PDT)`   | `time`               | `PT01_PSIG`           | `H2_pressure_PSIG`     |
| `TC05`              | `stack_temp_C`       | `PT02_PSIG`           | `O2_pressure_PSIG`     |
| `BGA01_pct`         | `O2_purity_pct`      | `Q_H2_in_H2s_SLPM`    | `H2_captured_SLPM`     |
| `BGA02_pct`         | `H2_purity_pct`      | `Q_H2_total_SLPM`     | `H2_total_SLPM`        |
| `Current_A`         | `current_A`          | `Q_H2_th_SLPM`        | `H2_theoretical_SLPM`  |
| `Voltage_V`         | `voltage_V`          | `Q_O2_*` (analogous)  | `O2_captured/total/theoretical_SLPM` |
| `MFM01_SLPM`        | `O2_flow_SLPM`       | `eta_H2`              | `eta_H2`               |
| `MFM02_SLPM`        | `H2_flow_SLPM`       | `mdot_H2_gps`         | `mdot_H2_gps`          |

`variables.py` is the single source of truth for each canonical variable's **label** and
**unit**. Chart code calls `variables.axis_label(name)` — labels are never hand-typed.

---

## Derived variables (`derived.py`)

The one place derived math is defined. `add_derived_columns(df, cell_count)` adds per-sample
columns; missing source columns simply yield no derived column (partial data still works).
Division is guarded so idle/zero rows produce NaN, not inf.

**Per-sample derived columns**

| canonical | definition | meaning |
|---|---|---|
| `dP_H2_O2_PSIG` | `H2_pressure − O2_pressure` | differential pressure (H₂−O₂) |
| `H2_impurity_pct` | `100 − H2_purity_pct` | O₂-in-H₂ (the "inverse of H₂ purity") |
| `O2_impurity_pct` | `100 − O2_purity_pct` | H₂-in-O₂ |
| `H2_capture_efficiency` | `H2_captured / H2_total` | fraction of total H₂ kept in H₂ stream |
| `O2_capture_efficiency` | `O2_captured / O2_total` | fraction of total O₂ kept in O₂ stream |
| `H2_crossover_SLPM` | `H2_total − H2_captured` | H₂ lost across the membrane |
| `O2_crossover_SLPM` | `O2_total − O2_captured` | O₂ lost across the membrane |
| `cell_voltage_V` | `voltage_V / cell_count` | per-cell voltage (cell count is per test!) |
| `power_W` | `voltage_V × current_A` | stack electrical power |
| `eta_O2` | `O2_total / O2_theoretical` | O₂ faradaic efficiency |
| `specific_energy_kWh_per_kg` | `(power_W/1000) / (mdot_H2_gps × 3.6)` | energy per kg H₂ |
| `flow_ratio_H2_O2` | `H2_flow / O2_flow` | should sit near the stoichiometric 2 |
| `apparent_resistance_ohm` | `voltage_V / current_A` | apparent stack resistance (running only) |
| `O2_purity_safety_margin_pct` | `O2_purity_pct − 96` | margin to ~4% H₂-in-O₂ flammability |

**Scalar reducers** — `compute_running_scalars(df, mask)` reduces any time-series/derived
column to a per-test scalar under a filter (default: current-flowing). Produces e.g.
`avg_h2_purity_running`, `avg_h2_impurity_running`, `avg_h2_capture_eff_running`,
`avg_o2_capture_eff_running`, `avg_dp_running`, `avg_cell_voltage_running`,
`avg_eta_h2_running`, `peak_temp_running`, `avg_power_running`,
`avg_specific_energy_running`, and `total_h2_produced_g_integral` (∫ mdot dt).

> Caveat: energy/efficiency metrics (`specific_energy`, `eta_*`, the mdot integral) are
> noisy at low current — the rig docs note faradaic values can exceed 1.0 from sensor noise
> below a few amps. Prefer the current-flowing-windowed reductions and treat low-current
> tails skeptically.

**Scalars read straight from results files** (already scalar): electrolysis — Avg H₂ Purity
in SS, Faradaic Eff, Yield Efficiency, Total H₂, Peak Temperature, Cell Count, …; pressure —
Abs Leak Rate, Diff Leak Rate, Max Diff Pressure, Tau, R² Abs Decay, P0/P-inf, Stack Mass,
Stack Resistance. See `variables.SCALAR_VARS` for the full keyed set.

---

## Chart types

### 1. `series_vs_time` — variable vs time (line)
One variable (or several unit-compatible ones) over time, default filter applied.
Runner: `scripts/run_series_vs_time.py` → `outputs/series_vs_time/<var>/SNxxxx_IDyy.png`.

### 2. `scalar_vs_scalar` — one point per (SN, test)
Aggregated scatter; each point is one test, colored by stack, ID-annotated. When the two
axes come from different test types, points are joined per **`config.SCALAR_JOIN_STRATEGY`**:
- `every_pair` *(default)* — cartesian electrolysis × pressure within a stack (every
  electrolysis-ID × pressure-ID combo); points annotated `ID{e}×ID{p}`.
- `per_test_nearest` — one point per electrolysis test, joined to the nearest-in-time
  pressure test on the same stack.
- `per_stack_latest` — one point per stack, each type's latest test.

**Point labels are composable** (`point_labels.py`). Each point's annotation is assembled from
named fields — `pair_id`, `elec_id`, `pres_id`, `elec_date`, `pres_date`, `current_run_time`,
`run_time` — so a label can carry provenance beyond the ID. Fields self-skip when their data is
absent, so an unused one just drops out. Which fields a chart uses is config, precedence
**`POINT_LABEL_BY_CHART` > `POINT_LABEL_MIXED_FIELDS` > `POINT_LABEL_DEFAULT_FIELDS`**:
- `POINT_LABEL_DEFAULT_FIELDS` — every scalar chart; default just `pair_id`.
- `POINT_LABEL_MIXED_FIELDS` — applies to *all* electrolysis×pressure charts (either
  orientation), since each point there joins one test of each type. Currently
  `pair_id, elec_date, pres_date, current_run_time` → e.g. `ID63×ID133, Jun 10, Jun 5, 176 min`.
  Same-type charts (electrolysis-only or pressure-only) are unaffected.
- `POINT_LABEL_BY_CHART` — keyed by the scalar pair `(yvar, xvar)`; special-case one chart.

Adding a new field is one function in `point_labels.FIELDS`.

Runner: `scripts/run_scalar_vs_scalar.py` → `outputs/scalar_vs_scalar/<y>_vs_<x>.png`.

### 3. `timeseries_scatter` — time-paired x-vs-y, colored by elapsed time
x and y sampled at the **same timestamp**, rendered as a single scatter colored by **elapsed
time** (gradient colormap + colorbar) — a way to encode time without a third axis.
Runner: `scripts/run_timeseries_scatter.py` → `outputs/timeseries_scatter/<y>_vs_<x>/SNxxxx_IDyy.png`.

> **Independent-panel principle (retained for future multi-panel use).** Each panel is
> produced by a self-contained `build(ax, fig)` closure that fully styles its own Axes
> (labels, reference lines, text boxes, notes). The default convenience renders just the
> gradient builder onto a single figure. If multiple panels are ever wanted again, `combine()`
> lays out subplots and calls the builders — it exposes **no** styling parameters, so there is
> nothing you can add to the *combined* image; all customization must happen inside a panel
> builder. A single escape hatch, `combine(..., post_combine_hook=…)`, exists for rare
> cross-panel needs — use sparingly.

### 4. `raw_correlations` sweep — every enabled X vs every enabled Y
`scripts/run_raw_correlations.py` generates all three families above across all tests,
driven by the `SWEEP_*` enable-lists in `config.py`. Narrow those lists to control volume.
Output tree: `outputs/raw_correlations/<chart_type>/<y>_vs_<x>/SNxxxx_IDyy.png`.

---

## Axis display ranges (`axis_range.py` + `config.py`)

By default an axis shows everything (matplotlib autoscale). Sometimes a cluster of outliers
compresses the region you care about — e.g. on **H₂ purity vs dP**, a handful of low-purity
startup points (<90%) squash the dense 97–99% band into the top sliver of the axis. Axis-range
policies fix that without touching the data. Three modes (`AxisRange`):

| mode | constructor | behavior |
|---|---|---|
| full | `AxisRange.full()` | show everything (default) |
| autoclip | `AxisRange.autoclip(lo_pct=, hi_pct=, pad_frac=)` | clip to a percentile band of the plotted data, padded — a "soft focus" on the dense body |
| manual | `AxisRange.manual(lo=, hi=)` | hard-coded limits; either side may be `None` to autoscale it |

**Autoclip is data-adaptive**, which is the whole point: the *same* policy focuses a test that
has a tight cluster + outlier tail, yet shows the full spread for a test whose data is genuinely
broad (the clip window then contains every point). E.g. with `autoclip(lo_pct=5, hi_pct=100)` on
H₂ purity vs dP: SN0018·ID61 (bimodal) clips to ~97.8–99.3% dropping the junk; SN0020·ID60
(spread 13–96%) keeps all points. One config entry, correct for both — no per-test rules.

Policies are looked up per axis with precedence **`AXIS_RANGE_BY_CHART` > `AXIS_RANGE_BY_VAR` >
`AXIS_RANGE_DEFAULT`** (all in `config.py`):
- `AXIS_RANGE_BY_CHART` — keyed by the scatter pair `(yvar, xvar)` (matching the
  `<yvar>_vs_<xvar>` output folder); value maps the axis `"x"`/`"y"` to override. Most specific.
- `AXIS_RANGE_BY_VAR` — keyed by variable; applies wherever that variable lands on an axis. Use
  when the clipping is intrinsic to the variable regardless of what it's plotted against. E.g.
  `eta_H2` is configured here (`autoclip(lo_pct=2, hi_pct=98)`): faradaic efficiency is physically
  ~[0,1] but low-current sensor noise spikes it past 1 (up to ~15), so every `<var> vs eta_H2`
  scatter clips both tails to the real body.
- `AXIS_RANGE_DEFAULT` — the fallback (currently `full()`).

Configured entries today: the H₂-purity axis of the two `…_vs_H2_purity_pct` orientations
(BY_CHART), and `eta_H2` everywhere it's an axis (BY_VAR). Range policies are applied by the
paired timeseries-scatter charts (the analysis/correlation views); the `series_vs_time` debug
charts are intentionally left full-range so spikes stay visible. Wiring another chart type is a
one-line `plotting.apply_chart_axis_ranges(ax, xvar=…, yvar=…, x=…, y=…)` call after plotting.

---

## General plotting layer (`plotting.py`)

One `draw(ax, series, *, xlabel, ylabel, title, ref_lines, textboxes, legend, …)` plus
composable helpers, so chart code never duplicates styling:
- multiple series, line or scatter, per-series label/color/marker/style
- `RefLine` — dashed constant reference lines (h/v) with optional inline labels (e.g. stoich
  ratio = 2, a safety limit)
- `TextBox` / `add_note` — in-axes annotations and figure footnotes
- `gradient_scatter` — colored-by-value scatter (used for time encoding)

Everything draws onto a caller-provided Axes, so the same code serves one-off and reused
figures.

---

## Performance (the thousands-of-charts path)

Volume comes from the *per-test* time-series charts (`series_vs_time`, `timeseries_scatter`);
scalar charts aggregate all tests onto one image and are cheap. Optimizations (`render.py`,
the sweep runner):

1. **Parse each CSV once.** The sweep loops outer = test, inner = variable pairs — a test's
   data + all derived columns are computed once and reused for every chart from that test.
2. **Object-oriented Agg, no pyplot.** Headless `Figure`+`FigureCanvasAgg`; rcParams set once.
3. **Reused figure per worker** (`ReusableFigure`, `ax.cla()` between charts) for line charts.
   The colorbar'd gradient panel uses a fresh figure (colorbars don't clear cleanly).
4. **Multiprocessing across tests** (`ProcessPoolExecutor`, `N_WORKERS`, Windows spawn-safe),
   partitioned by test so the load-once win is preserved.
5. **Cheap savefig:** no `bbox_inches="tight"` / per-figure `tight_layout`; `BULK_DPI`;
   tuned PNG compression; scatter decimation to `MAX_SCATTER_POINTS`.
6. **Optional feather cache** of derived frames (`USE_CACHE`) so reruns skip CSV parsing.

Knobs in `config.py`: `N_WORKERS`, `BULK_DPI`, `MAX_SCATTER_POINTS`, `FIGURE_REUSE`,
`USE_CACHE`, `BULK_PNG_COMPRESS_LEVEL`. On the 3-stack sample, the sweep runs ~2.9× faster
multiprocess vs serial; the gap widens with more stacks.

```powershell
python scripts/run_raw_correlations.py --count     # print planned totals, render nothing
python scripts/run_raw_correlations.py             # full run (multiprocess)
python scripts/run_raw_correlations.py --serial    # single process (benchmark baseline)
python scripts/run_raw_correlations.py --types series scalar   # subset of families
```

---

## Standalone: `scripts/plot_iv_curves.py`

Predates the framework; self-contained with its own config block.
- `STACKS`, `EXCLUDE_TEST_IDS`, `EXCLUDE_TEST_IDS_BY_STACK`
- per-stack chart `outputs/iv_curves/SN_{xxxx}/iv_sn{xxxx}.png`; combined overlay
  `outputs/combined/iv_sn{a}_sn{b}_sn{c}.png` (axes: V on x, I on y; one color per curve;
  legend carries `SN · ID · mean °C`).

---

## Chart labelling rules

A chart should be readable without going back to the source files. Provenance must appear on
the chart (legend, title, or annotation).

**Always include (non-negotiable):**
- **Test ID** — every trace in a legend carries its `ID{n}` (single-stack) or `SN{xxxx} · ID{n}`
  (multi-stack).
- **Stack SN** — title for single-stack charts, legend for multi-stack charts.

**Include when highly correlated with the y-axis** (it changes how the curve reads):
- **IV curves → temperature.** Include mean/setpoint temperature, e.g. `ID56 · 42 °C`.
- **Efficiency / voltage vs time → current setpoint and temperature.**
- **Pressure decay → starting pressure and temperature.**
- **Anything vs current → temperature** (most electrochemical quantities are T-dependent).

**Include when relevant to the comparison:** rework state (pre/post), date/timestamp for
degradation, operator/rig ID across setups.

**When in doubt, ask.** If a new chart type's dominant covariate isn't obvious, ask before
generating — a confidently-wrong label is worse than a missing one.

**Where to put it:** 1–3 fields → legend label, `·`-separated (`ID56 · 42 °C`); more → keep
legend short (ID + one key field), rest in title/footnote; single-value-per-chart facts →
title/subtitle.

---

## Requirements

- Python 3.10+
- `matplotlib`, `pandas`, `numpy` (and `pyarrow` only if you enable the feather cache)

(No `requirements.txt` yet — add one if the dependency set grows.)
