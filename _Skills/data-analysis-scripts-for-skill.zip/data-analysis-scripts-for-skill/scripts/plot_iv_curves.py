"""Generate IV curve plots from Stack QC electrolysis benchtop data.

For each stack in STACKS:
  - One chart with every IV curve from that stack's electrolysis tests
    -> outputs/iv_curves/SN_XXXX/iv_snXXXX.png

Plus one combined chart with all stacks overlaid
  -> outputs/combined/iv_snAAAA_snBBBB_snCCCC.png

Data layout (input):
  raw_data/Stack QC/SN{stack:04d}/02 Electrolysis Benchtop Test/
      ID{test_id}_SN{stack:04d}_{timestamp}_PDT/
          IV Curves/
              ID{test_id}_..._iv_curve_{N}.csv   (columns: I,V,T)

Test IDs count up globally, not per-stack.
"""

from __future__ import annotations

import csv
import re
from pathlib import Path

import matplotlib.pyplot as plt

# ---------------------------------------------------------------------------
# Config — edit these
# ---------------------------------------------------------------------------

# Stacks to include (serial numbers, integers)
STACKS: list[int] = [18, 19, 20]

# Global test ID exclusions (applied to every stack)
EXCLUDE_TEST_IDS: list[int] = []

# Per-stack test ID exclusions (overrides nothing, just adds to the global list)
# Example: {18: [56], 20: [58, 60]}
EXCLUDE_TEST_IDS_BY_STACK: dict[int, list[int]] = {}

# Project paths
PROJECT_ROOT = Path(__file__).resolve().parent.parent
RAW_DATA_ROOT = PROJECT_ROOT / "raw_data" / "Stack QC"
OUTPUT_ROOT = PROJECT_ROOT / "outputs"

# Plot styling
FIGSIZE = (10, 6)
DPI = 150
GRID = True

# Combined-chart palette: every curve gets its own distinct color, regardless of stack.
# Uses matplotlib's qualitative colormap; "tab10" gives 10 well-separated colors,
# "tab20" gives 20. Swap if you have more curves.
COMBINED_PALETTE: str = "tab10"

# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------

TEST_DIR_RE = re.compile(r"^ID(\d+)_SN(\d{4})_")
IV_CURVE_FILE_RE = re.compile(r"_iv_curve_(\d+)\.csv$", re.IGNORECASE)


def stack_dir(stack: int) -> Path:
    return RAW_DATA_ROOT / f"SN{stack:04d}" / "02 Electrolysis Benchtop Test"


def find_iv_curves(stack: int, excluded: set[int]) -> list[tuple[int, int, Path]]:
    """Return [(test_id, curve_index, csv_path), ...] sorted by test_id then curve_index."""
    root = stack_dir(stack)
    if not root.is_dir():
        return []

    results: list[tuple[int, int, Path]] = []
    for test_dir in sorted(root.iterdir()):
        if not test_dir.is_dir():
            continue
        m = TEST_DIR_RE.match(test_dir.name)
        if not m:
            continue
        test_id = int(m.group(1))
        if test_id in excluded:
            continue
        iv_dir = test_dir / "IV Curves"
        if not iv_dir.is_dir():
            continue
        for csv_path in sorted(iv_dir.glob("*_iv_curve_*.csv")):
            cm = IV_CURVE_FILE_RE.search(csv_path.name)
            if not cm:
                continue
            results.append((test_id, int(cm.group(1)), csv_path))
    results.sort()
    return results


def read_iv_csv(path: Path) -> tuple[list[float], list[float], list[float]]:
    """Read I, V, T columns from an iv_curve CSV. Skips blank rows."""
    i_vals: list[float] = []
    v_vals: list[float] = []
    t_vals: list[float] = []
    with path.open(newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                i = float(row["I"])
                v = float(row["V"])
            except (TypeError, ValueError, KeyError):
                continue
            i_vals.append(i)
            v_vals.append(v)
            try:
                t_vals.append(float(row["T"]))
            except (TypeError, ValueError, KeyError):
                pass
    return i_vals, v_vals, t_vals


def mean_temp_label(t_vals: list[float]) -> str:
    if not t_vals:
        return ""
    return f" · {sum(t_vals) / len(t_vals):.1f} °C"


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------

def style_axes(ax, title: str) -> None:
    ax.set_xlabel("Voltage (V)")
    ax.set_ylabel("Current (A)")
    ax.set_title(title)
    if GRID:
        ax.grid(True, linestyle="--", alpha=0.4)


def plot_stack(stack: int, curves: list[tuple[int, int, Path]], out_path: Path) -> None:
    """Plot every IV curve for one stack on a single chart."""
    fig, ax = plt.subplots(figsize=FIGSIZE)
    for test_id, curve_idx, csv_path in curves:
        i, v, t = read_iv_csv(csv_path)
        if not i:
            continue
        base = f"ID{test_id}" if curve_idx == 1 else f"ID{test_id} (#{curve_idx})"
        label = base + mean_temp_label(t)
        ax.plot(v, i, marker="o", markersize=3, linewidth=1.2, label=label)
    style_axes(ax, f"IV Curves — SN{stack:04d}")
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=DPI)
    plt.close(fig)
    print(f"  wrote {out_path.relative_to(PROJECT_ROOT)}")


def plot_combined(per_stack: dict[int, list[tuple[int, int, Path]]], out_path: Path) -> None:
    """Plot all stacks overlaid. Every curve gets its own distinct color."""
    fig, ax = plt.subplots(figsize=FIGSIZE)
    cmap = plt.get_cmap(COMBINED_PALETTE)
    n_colors = cmap.N if hasattr(cmap, "N") else 10

    color_idx = 0
    for stack in sorted(per_stack):
        for test_id, curve_idx, csv_path in per_stack[stack]:
            i, v, t = read_iv_csv(csv_path)
            if not i:
                continue
            base = f"SN{stack:04d} · ID{test_id}"
            if curve_idx != 1:
                base += f" (#{curve_idx})"
            label = base + mean_temp_label(t)
            ax.plot(
                v, i,
                color=cmap(color_idx % n_colors),
                marker="o", markersize=3, linewidth=1.2,
                alpha=0.9,
                label=label,
            )
            color_idx += 1
    style_axes(ax, "IV Curves — " + ", ".join(f"SN{s:04d}" for s in sorted(per_stack)))
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=DPI)
    plt.close(fig)
    print(f"  wrote {out_path.relative_to(PROJECT_ROOT)}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    per_stack: dict[int, list[tuple[int, int, Path]]] = {}
    for stack in STACKS:
        excluded = set(EXCLUDE_TEST_IDS) | set(EXCLUDE_TEST_IDS_BY_STACK.get(stack, []))
        curves = find_iv_curves(stack, excluded)
        per_stack[stack] = curves
        print(f"SN{stack:04d}: {len(curves)} IV curve(s) found")
        if not curves:
            continue
        out_path = OUTPUT_ROOT / "iv_curves" / f"SN_{stack:04d}" / f"iv_sn{stack:04d}.png"
        plot_stack(stack, curves, out_path)

    if sum(len(c) for c in per_stack.values()) == 0:
        print("No curves to combine.")
        return

    suffix = "_".join(f"sn{s:04d}" for s in sorted(per_stack))
    combined_path = OUTPUT_ROOT / "combined" / f"iv_{suffix}.png"
    plot_combined(per_stack, combined_path)


if __name__ == "__main__":
    main()
