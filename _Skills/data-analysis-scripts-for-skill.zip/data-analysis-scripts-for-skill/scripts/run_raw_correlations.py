"""Full raw-correlations sweep — every enabled X vs every enabled Y, across all tests.

Populates outputs/raw_correlations/ with three chart families:
  series_vs_time/<var>/SNxxxx_IDyy.png                  (each TS var vs time, per test)
  timeseries_scatter/<y>_vs_<x>/SNxxxx_IDyy.png         (paired scatter, per test)
  scalar_vs_scalar/<y>_vs_<x>.png                       (aggregated, one chart per pair)

Performance (see README "Performance" + analysis/render.py):
  - Per-test load-once: each test's CSV is parsed once; ALL of that test's charts are drawn
    from the in-memory derived frame.
  - Multiprocessing across tests (config.N_WORKERS), Windows spawn-safe.
  - Reused figure per worker for line charts; lower BULK_DPI; decimated scatters.
  - Scalar charts (cheap, aggregated) run in the main process.

Usage:
  python scripts/run_raw_correlations.py --count          # print planned totals, render nothing
  python scripts/run_raw_correlations.py                  # full run (multiprocess)
  python scripts/run_raw_correlations.py --serial         # single process (for benchmarking)
  python scripts/run_raw_correlations.py --workers 4
  python scripts/run_raw_correlations.py --types series scatter   # subset of chart families
"""

from __future__ import annotations

import argparse
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from analysis import config, filters, loaders  # noqa: E402
from analysis.charts import scalar_vs_scalar, series_vs_time, timeseries_scatter  # noqa: E402

OUT = config.OUTPUT_ROOT / "raw_correlations"

# Sweep sets (from config).
TIME_VARS = config.SWEEP_SERIES_TIME_VARS  # series-vs-time (includes debug channels)
TS_PAIRS = [(x, y) for y in config.SWEEP_TS_Y_VARS for x in config.SWEEP_TS_X_VARS if x != y]
SCALAR_PAIRS = [(x, y) for y in config.SWEEP_SCALAR_Y_VARS
                for x in config.SWEEP_SCALAR_X_VARS if x != y]

# Process-local reusable figure for line charts (one per worker, reused across all tests it handles).
_WORKER_FIG = None


def _worker_fig():
    global _WORKER_FIG
    if _WORKER_FIG is None:
        from analysis import render
        _WORKER_FIG = render.ReusableFigure()
    return _WORKER_FIG


def render_test(rec_and_types) -> int:
    """Render all per-test charts for one electrolysis test. Top-level => picklable for spawn."""
    rec, types = rec_and_types
    dd = loaders.load_derived(rec)
    if dd is None:
        return 0
    written = 0

    if "series" in types:
        fig = _worker_fig()
        for yvar in TIME_VARS:
            ax = fig.axes()
            if series_vs_time.draw_var_vs_time(ax, dd, yvar,
                                               title=f"{rec.label} — {yvar} vs time"):
                fig.save(OUT / "series_vs_time" / yvar / f"SN{rec.stack:04d}_ID{rec.test_id}.png")
                written += 1

    if "scatter" in types:
        mask = filters.apply_filter(dd)
        for xvar, yvar in TS_PAIRS:
            out = (OUT / "timeseries_scatter" / f"{yvar}_vs_{xvar}"
                   / f"SN{rec.stack:04d}_ID{rec.test_id}.png")
            if timeseries_scatter.paired_timeseries_scatter(
                    out, dd, xvar, yvar, mask=mask,
                    title=f"{rec.label} — {yvar} vs {xvar}", dpi=config.BULK_DPI) is not None:
                written += 1

    return written


def render_scalar_charts(tests) -> int:
    """Aggregated scalar-vs-scalar charts (main process)."""
    from analysis import render
    written = 0
    for xvar, yvar in SCALAR_PAIRS:
        fig, ax = render.new_figure(dpi=config.BULK_DPI)
        if scalar_vs_scalar.draw_scalar_vs_scalar(
                ax, xvar, yvar, tests=tests, annotate=True,
                title=f"{yvar} vs {xvar}  (join: {config.SCALAR_JOIN_STRATEGY})"):
            render.save_fig(fig, OUT / "scalar_vs_scalar" / f"{yvar}_vs_{xvar}.png",
                            dpi=config.BULK_DPI, compress_level=config.BULK_PNG_COMPRESS_LEVEL)
            written += 1
    return written


def plan(elec_tests, types) -> dict[str, int]:
    n = len(elec_tests)
    counts = {}
    if "series" in types:
        counts["series_vs_time"] = n * len(TIME_VARS)
    if "scatter" in types:
        counts["timeseries_scatter"] = n * len(TS_PAIRS)
    if "scalar" in types:
        counts["scalar_vs_scalar"] = len(SCALAR_PAIRS)
    counts["TOTAL (upper bound)"] = sum(counts.values())
    return counts


def main() -> None:
    ap = argparse.ArgumentParser(description="Raw correlations sweep")
    ap.add_argument("--count", action="store_true", help="print planned totals and exit")
    ap.add_argument("--serial", action="store_true", help="single process (benchmarking)")
    ap.add_argument("--workers", type=int, default=config.N_WORKERS)
    ap.add_argument("--types", nargs="+", default=["series", "scatter", "scalar"],
                    choices=["series", "scatter", "scalar"])
    args = ap.parse_args()

    all_tests = loaders.discover_tests()
    elec = [t for t in loaders.discover_tests("electrolysis") if t.raw_data_path]

    counts = plan(elec, args.types)
    print(f"Planned charts (upper bound; empty/all-NaN are skipped): {counts}")
    if args.count:
        return

    t0 = time.perf_counter()
    total = 0

    if "scalar" in args.types:
        total += render_scalar_charts(all_tests)

    per_test_types = [t for t in args.types if t in ("series", "scatter")]
    if per_test_types:
        work = [(rec, per_test_types) for rec in elec]
        if args.serial or args.workers <= 1:
            total += sum(render_test(w) for w in work)
        else:
            with ProcessPoolExecutor(max_workers=args.workers) as ex:
                total += sum(ex.map(render_test, work))

    dt = time.perf_counter() - t0
    mode = "serial" if (args.serial or args.workers <= 1) else f"{args.workers} workers"
    print(f"raw_correlations: wrote {total} charts in {dt:.1f}s ({mode}) "
          f"-> {OUT.relative_to(config.PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
