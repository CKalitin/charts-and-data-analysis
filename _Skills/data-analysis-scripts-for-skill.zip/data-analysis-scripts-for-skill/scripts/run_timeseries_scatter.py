"""Generate paired time-series scatter charts (standard + time-gradient panels).

For every electrolysis test and every (x, y) pair from the configured time-series sweep
sets, render the two-panel image (top: standard scatter; bottom: colored by elapsed time).

Output: outputs/timeseries_scatter/<yvar>_vs_<xvar>/SNxxxx_IDyy.png
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from analysis import config, derived, filters, loaders  # noqa: E402
from analysis.charts import timeseries_scatter  # noqa: E402

OUT = config.OUTPUT_ROOT / "timeseries_scatter"

PAIRS = [(x, y) for y in config.SWEEP_TS_Y_VARS for x in config.SWEEP_TS_X_VARS if x != y]


def main() -> None:
    tests = [t for t in loaders.discover_tests("electrolysis") if t.raw_data_path]
    written = 0
    for rec in tests:
        df = loaders.load_timeseries(rec)
        if df is None:
            continue
        dd = derived.add_derived_columns(df, loaders.get_cell_count(rec))
        mask = filters.apply_filter(dd)
        for xvar, yvar in PAIRS:
            out = OUT / f"{yvar}_vs_{xvar}" / f"SN{rec.stack:04d}_ID{rec.test_id}.png"
            path = timeseries_scatter.paired_timeseries_scatter(
                out, dd, xvar, yvar, mask=mask,
                title=f"{rec.label} — {yvar} vs {xvar}")
            if path is not None:
                written += 1
    print(f"timeseries_scatter: wrote {written} charts under {OUT.relative_to(config.PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
