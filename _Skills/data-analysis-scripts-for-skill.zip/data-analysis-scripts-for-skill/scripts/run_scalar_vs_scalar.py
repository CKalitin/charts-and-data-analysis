"""Generate scalar-vs-scalar charts (one point per test, cross-test-type joined).

For every (x, y) in the configured scalar sweep sets, render one aggregated scatter across
all stacks/tests. Cross-type pairs (electrolysis scalar vs pressure scalar) are joined per
config.SCALAR_JOIN_STRATEGY.

Output: outputs/scalar_vs_scalar/<yvar>_vs_<xvar>.png
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from analysis import config, loaders, render  # noqa: E402
from analysis.charts import scalar_vs_scalar  # noqa: E402

OUT = config.OUTPUT_ROOT / "scalar_vs_scalar"


def main() -> None:
    tests = loaders.discover_tests()
    written = 0
    for yvar in config.SWEEP_SCALAR_Y_VARS:
        for xvar in config.SWEEP_SCALAR_X_VARS:
            if xvar == yvar:
                continue
            fig, ax = render.new_figure()
            ok = scalar_vs_scalar.draw_scalar_vs_scalar(
                ax, xvar, yvar, tests=tests, annotate=True,
                title=f"{yvar} vs {xvar}  (join: {config.SCALAR_JOIN_STRATEGY})")
            if not ok:
                print(f"  skip {yvar}_vs_{xvar} (no points)")
                continue
            render.save_fig(fig, OUT / f"{yvar}_vs_{xvar}.png")
            written += 1
    print(f"scalar_vs_scalar: wrote {written} charts under {OUT.relative_to(config.PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
