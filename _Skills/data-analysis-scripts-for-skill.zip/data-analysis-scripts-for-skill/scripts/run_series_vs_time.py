"""Generate series-vs-time charts for each electrolysis test.

For every electrolysis test (with time-series data) and every variable in the configured
time-series sweep set, render <variable> vs time.

Output: outputs/series_vs_time/<variable>/SNxxxx_IDyy.png

Config: analysis/config.py  (STACKS, EXCLUDE_*, SWEEP_TS_* , DEFAULT_TS_FILTER, BULK_DPI).
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from analysis import config, derived, loaders, render  # noqa: E402
from analysis.charts import series_vs_time  # noqa: E402

OUT = config.OUTPUT_ROOT / "series_vs_time"

# Variables to plot against time (dedicated list; includes series-only debug channels).
TIME_VARS = config.SWEEP_SERIES_TIME_VARS


def main() -> None:
    tests = [t for t in loaders.discover_tests("electrolysis") if t.raw_data_path]
    fig = render.ReusableFigure()
    written = 0
    for rec in tests:
        df = loaders.load_timeseries(rec)
        if df is None:
            print(f"  skip {rec.label} (no data)")
            continue
        dd = derived.add_derived_columns(df, loaders.get_cell_count(rec))
        for yvar in TIME_VARS:
            ax = fig.axes()
            ok = series_vs_time.draw_var_vs_time(
                ax, dd, yvar, title=f"{rec.label} — {yvar} vs time")
            if not ok:
                continue
            fig.save(OUT / yvar / f"SN{rec.stack:04d}_ID{rec.test_id}.png")
            written += 1
    print(f"series_vs_time: wrote {written} charts under {OUT.relative_to(config.PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
